﻿namespace MovieForRent
{
    partial class frmSearchForCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSearchForCustomer));
            this.groupBoxFind = new System.Windows.Forms.GroupBox();
            this.cbGenre = new System.Windows.Forms.ComboBox();
            this.gENREBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dbMovieForRentDataSet = new MovieForRent.dbMovieForRentDataSet();
            this.groupBoxResult = new System.Windows.Forms.GroupBox();
            this.dgvResult = new System.Windows.Forms.DataGridView();
            this.colMovieName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDirector = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGenre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMovieID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colReleaseYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLength = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIMDB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSpotSummary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colImagePath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTrailerPath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtKeyword = new System.Windows.Forms.TextBox();
            this.lbKeyword = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lbSearchCar = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbIMDB = new System.Windows.Forms.Label();
            this.lbLength = new System.Windows.Forms.Label();
            this.lbReleaseYear = new System.Windows.Forms.Label();
            this.rtxtSpotSummary = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.axWMPTrailer = new AxWMPLib.AxWindowsMediaPlayer();
            this.pbMovie = new System.Windows.Forms.PictureBox();
            this.gENRETableAdapter = new MovieForRent.dbMovieForRentDataSetTableAdapters.GENRETableAdapter();
            this.dbMovieForRentDataSet1 = new MovieForRent.dbMovieForRentDataSet();
            this.genreTableAdapter1 = new MovieForRent.dbMovieForRentDataSetTableAdapters.GENRETableAdapter();
            this.tableAdapterManager1 = new MovieForRent.dbMovieForRentDataSetTableAdapters.TableAdapterManager();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBoxFind.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gENREBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet)).BeginInit();
            this.groupBoxResult.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axWMPTrailer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMovie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxFind
            // 
            this.groupBoxFind.Controls.Add(this.cbGenre);
            this.groupBoxFind.Controls.Add(this.groupBoxResult);
            this.groupBoxFind.Controls.Add(this.txtKeyword);
            this.groupBoxFind.Controls.Add(this.lbKeyword);
            this.groupBoxFind.Controls.Add(this.btnSearch);
            this.groupBoxFind.Location = new System.Drawing.Point(31, 93);
            this.groupBoxFind.Name = "groupBoxFind";
            this.groupBoxFind.Size = new System.Drawing.Size(494, 363);
            this.groupBoxFind.TabIndex = 8;
            this.groupBoxFind.TabStop = false;
            this.groupBoxFind.Text = "Search";
            // 
            // cbGenre
            // 
            this.cbGenre.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.cbGenre.DataSource = this.gENREBindingSource;
            this.cbGenre.DisplayMember = "GENRENAME";
            this.cbGenre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbGenre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbGenre.FormattingEnabled = true;
            this.cbGenre.Location = new System.Drawing.Point(301, 41);
            this.cbGenre.Name = "cbGenre";
            this.cbGenre.Size = new System.Drawing.Size(92, 24);
            this.cbGenre.TabIndex = 10;
            this.cbGenre.ValueMember = "GENREID";
            // 
            // gENREBindingSource
            // 
            this.gENREBindingSource.DataMember = "GENRE";
            this.gENREBindingSource.DataSource = this.dbMovieForRentDataSet;
            // 
            // dbMovieForRentDataSet
            // 
            this.dbMovieForRentDataSet.DataSetName = "dbMovieForRentDataSet";
            this.dbMovieForRentDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupBoxResult
            // 
            this.groupBoxResult.Controls.Add(this.dgvResult);
            this.groupBoxResult.Cursor = System.Windows.Forms.Cursors.Hand;
            this.groupBoxResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.groupBoxResult.Location = new System.Drawing.Point(0, 93);
            this.groupBoxResult.Name = "groupBoxResult";
            this.groupBoxResult.Size = new System.Drawing.Size(493, 271);
            this.groupBoxResult.TabIndex = 9;
            this.groupBoxResult.TabStop = false;
            this.groupBoxResult.Text = "List of Movies";
            // 
            // dgvResult
            // 
            this.dgvResult.AllowUserToAddRows = false;
            this.dgvResult.AllowUserToDeleteRows = false;
            this.dgvResult.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvResult.BackgroundColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvResult.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResult.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMovieName,
            this.colDirector,
            this.colGenre,
            this.colMovieID,
            this.colReleaseYear,
            this.colLength,
            this.colIMDB,
            this.colSpotSummary,
            this.colImagePath,
            this.colTrailerPath});
            this.dgvResult.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgvResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvResult.Location = new System.Drawing.Point(3, 16);
            this.dgvResult.Name = "dgvResult";
            this.dgvResult.ReadOnly = true;
            this.dgvResult.Size = new System.Drawing.Size(487, 252);
            this.dgvResult.TabIndex = 0;
            this.dgvResult.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvResult_CellClick);
            // 
            // colMovieName
            // 
            this.colMovieName.DataPropertyName = "NAME";
            this.colMovieName.HeaderText = "Movie Name";
            this.colMovieName.Name = "colMovieName";
            this.colMovieName.ReadOnly = true;
            // 
            // colDirector
            // 
            this.colDirector.DataPropertyName = "DIRECTOR";
            this.colDirector.HeaderText = "Director";
            this.colDirector.Name = "colDirector";
            this.colDirector.ReadOnly = true;
            // 
            // colGenre
            // 
            this.colGenre.DataPropertyName = "Genres";
            this.colGenre.HeaderText = "Genre(s)";
            this.colGenre.Name = "colGenre";
            this.colGenre.ReadOnly = true;
            this.colGenre.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colMovieID
            // 
            this.colMovieID.DataPropertyName = "MOVIEID";
            this.colMovieID.HeaderText = "MovieID";
            this.colMovieID.Name = "colMovieID";
            this.colMovieID.ReadOnly = true;
            this.colMovieID.Visible = false;
            // 
            // colReleaseYear
            // 
            this.colReleaseYear.DataPropertyName = "ReleaseYear";
            this.colReleaseYear.HeaderText = "ReleaseYear";
            this.colReleaseYear.Name = "colReleaseYear";
            this.colReleaseYear.ReadOnly = true;
            this.colReleaseYear.Visible = false;
            // 
            // colLength
            // 
            this.colLength.DataPropertyName = "Length";
            this.colLength.HeaderText = "Lenght";
            this.colLength.Name = "colLength";
            this.colLength.ReadOnly = true;
            this.colLength.Visible = false;
            // 
            // colIMDB
            // 
            this.colIMDB.DataPropertyName = "IMDB";
            this.colIMDB.HeaderText = "IMDB";
            this.colIMDB.Name = "colIMDB";
            this.colIMDB.ReadOnly = true;
            this.colIMDB.Visible = false;
            // 
            // colSpotSummary
            // 
            this.colSpotSummary.DataPropertyName = "SPOTSUMMARY";
            this.colSpotSummary.HeaderText = "Spot Summary";
            this.colSpotSummary.Name = "colSpotSummary";
            this.colSpotSummary.ReadOnly = true;
            this.colSpotSummary.Visible = false;
            // 
            // colImagePath
            // 
            this.colImagePath.DataPropertyName = "ImagePath";
            this.colImagePath.HeaderText = "ImagePath";
            this.colImagePath.Name = "colImagePath";
            this.colImagePath.ReadOnly = true;
            this.colImagePath.Visible = false;
            // 
            // colTrailerPath
            // 
            this.colTrailerPath.DataPropertyName = "TrailerPath";
            this.colTrailerPath.HeaderText = "TrailerPath";
            this.colTrailerPath.Name = "colTrailerPath";
            this.colTrailerPath.ReadOnly = true;
            this.colTrailerPath.Visible = false;
            // 
            // txtKeyword
            // 
            this.txtKeyword.AccessibleDescription = "asdasda";
            this.txtKeyword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKeyword.Location = new System.Drawing.Point(70, 43);
            this.txtKeyword.Name = "txtKeyword";
            this.txtKeyword.Size = new System.Drawing.Size(217, 22);
            this.txtKeyword.TabIndex = 1;
            this.txtKeyword.Text = "Enter Movie Name or Director";
            this.txtKeyword.Enter += new System.EventHandler(this.txtKeyword_Enter);
            this.txtKeyword.Leave += new System.EventHandler(this.txtKeyword_Leave);
            // 
            // lbKeyword
            // 
            this.lbKeyword.AutoSize = true;
            this.lbKeyword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKeyword.Location = new System.Drawing.Point(6, 46);
            this.lbKeyword.Name = "lbKeyword";
            this.lbKeyword.Size = new System.Drawing.Size(63, 16);
            this.lbKeyword.TabIndex = 0;
            this.lbKeyword.Text = "Keyword:";
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSearch.Location = new System.Drawing.Point(404, 38);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(71, 26);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lbSearchCar
            // 
            this.lbSearchCar.AutoSize = true;
            this.lbSearchCar.Font = new System.Drawing.Font("Microsoft Sans Serif", 27F);
            this.lbSearchCar.ForeColor = System.Drawing.Color.Blue;
            this.lbSearchCar.Location = new System.Drawing.Point(209, 23);
            this.lbSearchCar.Name = "lbSearchCar";
            this.lbSearchCar.Size = new System.Drawing.Size(167, 40);
            this.lbSearchCar.TabIndex = 7;
            this.lbSearchCar.Text = "SEARCH";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbIMDB);
            this.groupBox1.Controls.Add(this.lbLength);
            this.groupBox1.Controls.Add(this.lbReleaseYear);
            this.groupBox1.Controls.Add(this.rtxtSpotSummary);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.axWMPTrailer);
            this.groupBox1.Controls.Add(this.pbMovie);
            this.groupBox1.Location = new System.Drawing.Point(554, 93);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(516, 364);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Movie Detail";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // lbIMDB
            // 
            this.lbIMDB.AutoSize = true;
            this.lbIMDB.Location = new System.Drawing.Point(426, 329);
            this.lbIMDB.Name = "lbIMDB";
            this.lbIMDB.Size = new System.Drawing.Size(0, 13);
            this.lbIMDB.TabIndex = 22;
            // 
            // lbLength
            // 
            this.lbLength.AutoSize = true;
            this.lbLength.Location = new System.Drawing.Point(267, 329);
            this.lbLength.Name = "lbLength";
            this.lbLength.Size = new System.Drawing.Size(0, 13);
            this.lbLength.TabIndex = 21;
            // 
            // lbReleaseYear
            // 
            this.lbReleaseYear.AutoSize = true;
            this.lbReleaseYear.Location = new System.Drawing.Point(135, 328);
            this.lbReleaseYear.Name = "lbReleaseYear";
            this.lbReleaseYear.Size = new System.Drawing.Size(0, 13);
            this.lbReleaseYear.TabIndex = 20;
            // 
            // rtxtSpotSummary
            // 
            this.rtxtSpotSummary.BackColor = System.Drawing.Color.White;
            this.rtxtSpotSummary.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtxtSpotSummary.ForeColor = System.Drawing.Color.Black;
            this.rtxtSpotSummary.Location = new System.Drawing.Point(22, 221);
            this.rtxtSpotSummary.Name = "rtxtSpotSummary";
            this.rtxtSpotSummary.ReadOnly = true;
            this.rtxtSpotSummary.Size = new System.Drawing.Size(478, 83);
            this.rtxtSpotSummary.TabIndex = 15;
            this.rtxtSpotSummary.Text = "SpotSummary";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(368, 326);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 16);
            this.label3.TabIndex = 19;
            this.label3.Text = "IMDB:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(207, 326);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 16);
            this.label2.TabIndex = 18;
            this.label2.Text = "Length: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(19, 326);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 16);
            this.label1.TabIndex = 17;
            this.label1.Text = "Release Year:";
            // 
            // axWMPTrailer
            // 
            this.axWMPTrailer.Enabled = true;
            this.axWMPTrailer.Location = new System.Drawing.Point(181, 25);
            this.axWMPTrailer.Name = "axWMPTrailer";
            this.axWMPTrailer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWMPTrailer.OcxState")));
            this.axWMPTrailer.Size = new System.Drawing.Size(319, 190);
            this.axWMPTrailer.TabIndex = 16;
            // 
            // pbMovie
            // 
            this.pbMovie.Location = new System.Drawing.Point(22, 25);
            this.pbMovie.Name = "pbMovie";
            this.pbMovie.Size = new System.Drawing.Size(153, 190);
            this.pbMovie.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMovie.TabIndex = 0;
            this.pbMovie.TabStop = false;
            // 
            // gENRETableAdapter
            // 
            this.gENRETableAdapter.ClearBeforeFill = true;
            // 
            // dbMovieForRentDataSet1
            // 
            this.dbMovieForRentDataSet1.DataSetName = "dbMovieForRentDataSet";
            this.dbMovieForRentDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // genreTableAdapter1
            // 
            this.genreTableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.GENRETableAdapter = this.gENRETableAdapter;
            this.tableAdapterManager1.UpdateOrder = MovieForRent.dbMovieForRentDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logOutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1093, 24);
            this.menuStrip1.TabIndex = 11;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.logOutToolStripMenuItem.Text = "Log Out";
            this.logOutToolStripMenuItem.Click += new System.EventHandler(this.logOutToolStripMenuItem_Click);
            // 
            // frmSearchForCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1093, 508);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lbSearchCar);
            this.Controls.Add(this.groupBoxFind);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.Color.MidnightBlue;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmSearchForCustomer";
            this.Text = "Search Film";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmSearchForCustomer_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBoxFind.ResumeLayout(false);
            this.groupBoxFind.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gENREBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet)).EndInit();
            this.groupBoxResult.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axWMPTrailer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMovie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxFind;
        private System.Windows.Forms.TextBox txtKeyword;
        private System.Windows.Forms.Label lbKeyword;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.GroupBox groupBoxResult;
        private System.Windows.Forms.DataGridView dgvResult;
        private System.Windows.Forms.Label lbSearchCar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pbMovie;
        private System.Windows.Forms.RichTextBox rtxtSpotSummary;
        private AxWMPLib.AxWindowsMediaPlayer axWMPTrailer;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbGenre;
        private dbMovieForRentDataSet dbMovieForRentDataSet;
        private System.Windows.Forms.BindingSource gENREBindingSource;
        private dbMovieForRentDataSetTableAdapters.GENRETableAdapter gENRETableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMovieName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDirector;
        private System.Windows.Forms.DataGridViewTextBoxColumn colGenre;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMovieID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colReleaseYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLength;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIMDB;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSpotSummary;
        private System.Windows.Forms.DataGridViewTextBoxColumn colImagePath;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTrailerPath;
        private dbMovieForRentDataSet dbMovieForRentDataSet1;
        private dbMovieForRentDataSetTableAdapters.GENRETableAdapter genreTableAdapter1;
        private dbMovieForRentDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.Label lbIMDB;
        private System.Windows.Forms.Label lbLength;
        private System.Windows.Forms.Label lbReleaseYear;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
    }
}

