﻿namespace MovieForRent
{
    partial class frmSearchForCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSearchForCustomer));
            this.groupBoxFind = new System.Windows.Forms.GroupBox();
            this.cbGenre = new System.Windows.Forms.ComboBox();
            this.gENREBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dbMovieForRentDataSet = new MovieForRent.dbMovieForRentDataSet();
            this.groupBoxResult = new System.Windows.Forms.GroupBox();
            this.dgvResult = new System.Windows.Forms.DataGridView();
            this.colMovieName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDirector = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGenre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMovieID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colReleaseYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLength = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIMDB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSpotSummary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colImagePath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTrailerPath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtKeyword = new System.Windows.Forms.TextBox();
            this.lbKeyword = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lbSearchCar = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rtxtSpotSummary = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.axWMPTrailer = new AxWMPLib.AxWindowsMediaPlayer();
            this.pbMovie = new System.Windows.Forms.PictureBox();
            this.gENRETableAdapter = new MovieForRent.dbMovieForRentDataSetTableAdapters.GENRETableAdapter();
            this.fillByToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillByToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.dbMovieForRentDataSet1 = new MovieForRent.dbMovieForRentDataSet();
            this.genreTableAdapter1 = new MovieForRent.dbMovieForRentDataSetTableAdapters.GENRETableAdapter();
            this.tableAdapterManager1 = new MovieForRent.dbMovieForRentDataSetTableAdapters.TableAdapterManager();
            this.groupBoxFind.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gENREBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet)).BeginInit();
            this.groupBoxResult.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axWMPTrailer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMovie)).BeginInit();
            this.fillByToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxFind
            // 
            this.groupBoxFind.Controls.Add(this.cbGenre);
            this.groupBoxFind.Controls.Add(this.groupBoxResult);
            this.groupBoxFind.Controls.Add(this.txtKeyword);
            this.groupBoxFind.Controls.Add(this.lbKeyword);
            this.groupBoxFind.Controls.Add(this.btnSearch);
            this.groupBoxFind.Location = new System.Drawing.Point(31, 93);
            this.groupBoxFind.Name = "groupBoxFind";
            this.groupBoxFind.Size = new System.Drawing.Size(494, 411);
            this.groupBoxFind.TabIndex = 8;
            this.groupBoxFind.TabStop = false;
            this.groupBoxFind.Text = "Search";
            // 
            // cbGenre
            // 
            this.cbGenre.DataSource = this.gENREBindingSource;
            this.cbGenre.DisplayMember = "GENRENAME";
            this.cbGenre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbGenre.FormattingEnabled = true;
            this.cbGenre.Location = new System.Drawing.Point(308, 43);
            this.cbGenre.Name = "cbGenre";
            this.cbGenre.Size = new System.Drawing.Size(92, 21);
            this.cbGenre.TabIndex = 10;
            this.cbGenre.ValueMember = "GENREID";
            // 
            // gENREBindingSource
            // 
            this.gENREBindingSource.DataMember = "GENRE";
            this.gENREBindingSource.DataSource = this.dbMovieForRentDataSet;
            // 
            // dbMovieForRentDataSet
            // 
            this.dbMovieForRentDataSet.DataSetName = "dbMovieForRentDataSet";
            this.dbMovieForRentDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupBoxResult
            // 
            this.groupBoxResult.Controls.Add(this.dgvResult);
            this.groupBoxResult.Cursor = System.Windows.Forms.Cursors.Hand;
            this.groupBoxResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxResult.Location = new System.Drawing.Point(0, 93);
            this.groupBoxResult.Name = "groupBoxResult";
            this.groupBoxResult.Size = new System.Drawing.Size(493, 318);
            this.groupBoxResult.TabIndex = 9;
            this.groupBoxResult.TabStop = false;
            this.groupBoxResult.Text = "List of Movies";
            // 
            // dgvResult
            // 
            this.dgvResult.AllowUserToAddRows = false;
            this.dgvResult.AllowUserToDeleteRows = false;
            this.dgvResult.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvResult.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResult.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMovieName,
            this.colDirector,
            this.colGenre,
            this.colMovieID,
            this.colReleaseYear,
            this.colLength,
            this.colIMDB,
            this.colSpotSummary,
            this.colImagePath,
            this.colTrailerPath});
            this.dgvResult.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgvResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvResult.Location = new System.Drawing.Point(3, 18);
            this.dgvResult.Name = "dgvResult";
            this.dgvResult.ReadOnly = true;
            this.dgvResult.Size = new System.Drawing.Size(487, 297);
            this.dgvResult.TabIndex = 0;
            this.dgvResult.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvResult_CellClick);
            // 
            // colMovieName
            // 
            this.colMovieName.DataPropertyName = "NAME";
            this.colMovieName.HeaderText = "Movie Name";
            this.colMovieName.Name = "colMovieName";
            this.colMovieName.ReadOnly = true;
            // 
            // colDirector
            // 
            this.colDirector.DataPropertyName = "DIRECTOR";
            this.colDirector.HeaderText = "Director";
            this.colDirector.Name = "colDirector";
            this.colDirector.ReadOnly = true;
            // 
            // colGenre
            // 
            this.colGenre.DataPropertyName = "Genres";
            this.colGenre.HeaderText = "Genre(s)";
            this.colGenre.Name = "colGenre";
            this.colGenre.ReadOnly = true;
            this.colGenre.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // colMovieID
            // 
            this.colMovieID.DataPropertyName = "MOVIEID";
            this.colMovieID.HeaderText = "MovieID";
            this.colMovieID.Name = "colMovieID";
            this.colMovieID.ReadOnly = true;
            this.colMovieID.Visible = false;
            // 
            // colReleaseYear
            // 
            this.colReleaseYear.DataPropertyName = "ReleaseYear";
            this.colReleaseYear.HeaderText = "ReleaseYear";
            this.colReleaseYear.Name = "colReleaseYear";
            this.colReleaseYear.ReadOnly = true;
            this.colReleaseYear.Visible = false;
            // 
            // colLength
            // 
            this.colLength.DataPropertyName = "Length";
            this.colLength.HeaderText = "Lenght";
            this.colLength.Name = "colLength";
            this.colLength.ReadOnly = true;
            this.colLength.Visible = false;
            // 
            // colIMDB
            // 
            this.colIMDB.DataPropertyName = "IMDB";
            this.colIMDB.HeaderText = "IMDB";
            this.colIMDB.Name = "colIMDB";
            this.colIMDB.ReadOnly = true;
            this.colIMDB.Visible = false;
            // 
            // colSpotSummary
            // 
            this.colSpotSummary.DataPropertyName = "SPOTSUMMARY";
            this.colSpotSummary.HeaderText = "Spot Summary";
            this.colSpotSummary.Name = "colSpotSummary";
            this.colSpotSummary.ReadOnly = true;
            this.colSpotSummary.Visible = false;
            // 
            // colImagePath
            // 
            this.colImagePath.DataPropertyName = "ImagePath";
            this.colImagePath.HeaderText = "ImagePath";
            this.colImagePath.Name = "colImagePath";
            this.colImagePath.ReadOnly = true;
            this.colImagePath.Visible = false;
            // 
            // colTrailerPath
            // 
            this.colTrailerPath.DataPropertyName = "TrailerPath";
            this.colTrailerPath.HeaderText = "TrailerPath";
            this.colTrailerPath.Name = "colTrailerPath";
            this.colTrailerPath.ReadOnly = true;
            this.colTrailerPath.Visible = false;
            // 
            // txtKeyword
            // 
            this.txtKeyword.AccessibleDescription = "asdasda";
            this.txtKeyword.Location = new System.Drawing.Point(85, 44);
            this.txtKeyword.Name = "txtKeyword";
            this.txtKeyword.Size = new System.Drawing.Size(217, 20);
            this.txtKeyword.TabIndex = 1;
            this.txtKeyword.Text = "Enter Movie Name or Director";
            this.txtKeyword.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtKeyword_KeyDown);
            this.txtKeyword.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtKeyword_KeyUp);
            this.txtKeyword.MouseDown += new System.Windows.Forms.MouseEventHandler(this.txtKeyword_MouseDown);
            // 
            // lbKeyword
            // 
            this.lbKeyword.AutoSize = true;
            this.lbKeyword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKeyword.Location = new System.Drawing.Point(-1, 41);
            this.lbKeyword.Name = "lbKeyword";
            this.lbKeyword.Size = new System.Drawing.Size(73, 20);
            this.lbKeyword.TabIndex = 0;
            this.lbKeyword.Text = "Keyword:";
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSearch.Location = new System.Drawing.Point(416, 41);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(33, 22);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lbSearchCar
            // 
            this.lbSearchCar.AutoSize = true;
            this.lbSearchCar.Font = new System.Drawing.Font("Microsoft Sans Serif", 27F);
            this.lbSearchCar.ForeColor = System.Drawing.Color.Blue;
            this.lbSearchCar.Location = new System.Drawing.Point(440, 19);
            this.lbSearchCar.Name = "lbSearchCar";
            this.lbSearchCar.Size = new System.Drawing.Size(167, 40);
            this.lbSearchCar.TabIndex = 7;
            this.lbSearchCar.Text = "SEARCH";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rtxtSpotSummary);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.axWMPTrailer);
            this.groupBox1.Controls.Add(this.pbMovie);
            this.groupBox1.Location = new System.Drawing.Point(554, 93);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(516, 411);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Movie Detail";
            // 
            // rtxtSpotSummary
            // 
            this.rtxtSpotSummary.BackColor = System.Drawing.SystemColors.Control;
            this.rtxtSpotSummary.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtxtSpotSummary.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtxtSpotSummary.ForeColor = System.Drawing.Color.Black;
            this.rtxtSpotSummary.Location = new System.Drawing.Point(22, 221);
            this.rtxtSpotSummary.Name = "rtxtSpotSummary";
            this.rtxtSpotSummary.ReadOnly = true;
            this.rtxtSpotSummary.Size = new System.Drawing.Size(488, 82);
            this.rtxtSpotSummary.TabIndex = 15;
            this.rtxtSpotSummary.Text = "SpotSummary";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(74, 368);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 16);
            this.label4.TabIndex = 20;
            this.label4.Text = "Keyword";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(74, 347);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 16);
            this.label3.TabIndex = 19;
            this.label3.Text = "Keyword";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(74, 326);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 16);
            this.label2.TabIndex = 18;
            this.label2.Text = "Keyword";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(74, 306);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 16);
            this.label1.TabIndex = 17;
            this.label1.Text = "Keyword";
            // 
            // axWMPTrailer
            // 
            this.axWMPTrailer.Enabled = true;
            this.axWMPTrailer.Location = new System.Drawing.Point(181, 25);
            this.axWMPTrailer.Name = "axWMPTrailer";
            this.axWMPTrailer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWMPTrailer.OcxState")));
            this.axWMPTrailer.Size = new System.Drawing.Size(309, 190);
            this.axWMPTrailer.TabIndex = 16;
            this.axWMPTrailer.Enter += new System.EventHandler(this.axWindowsMediaPlayer1_Enter);
            // 
            // pbMovie
            // 
            this.pbMovie.Location = new System.Drawing.Point(22, 25);
            this.pbMovie.Name = "pbMovie";
            this.pbMovie.Size = new System.Drawing.Size(153, 190);
            this.pbMovie.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMovie.TabIndex = 0;
            this.pbMovie.TabStop = false;
            // 
            // gENRETableAdapter
            // 
            this.gENRETableAdapter.ClearBeforeFill = true;
            // 
            // fillByToolStrip
            // 
            this.fillByToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByToolStripButton});
            this.fillByToolStrip.Location = new System.Drawing.Point(0, 0);
            this.fillByToolStrip.Name = "fillByToolStrip";
            this.fillByToolStrip.Size = new System.Drawing.Size(1107, 25);
            this.fillByToolStrip.TabIndex = 11;
            this.fillByToolStrip.Text = "fillByToolStrip";
            // 
            // fillByToolStripButton
            // 
            this.fillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByToolStripButton.Name = "fillByToolStripButton";
            this.fillByToolStripButton.Size = new System.Drawing.Size(39, 22);
            this.fillByToolStripButton.Text = "FillBy";
            this.fillByToolStripButton.Click += new System.EventHandler(this.fillByToolStripButton_Click);
            // 
            // dbMovieForRentDataSet1
            // 
            this.dbMovieForRentDataSet1.DataSetName = "dbMovieForRentDataSet";
            this.dbMovieForRentDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // genreTableAdapter1
            // 
            this.genreTableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.GENRETableAdapter = this.gENRETableAdapter;
            this.tableAdapterManager1.UpdateOrder = MovieForRent.dbMovieForRentDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1107, 531);
            this.Controls.Add(this.fillByToolStrip);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lbSearchCar);
            this.Controls.Add(this.groupBoxFind);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBoxFind.ResumeLayout(false);
            this.groupBoxFind.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gENREBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet)).EndInit();
            this.groupBoxResult.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axWMPTrailer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMovie)).EndInit();
            this.fillByToolStrip.ResumeLayout(false);
            this.fillByToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxFind;
        private System.Windows.Forms.TextBox txtKeyword;
        private System.Windows.Forms.Label lbKeyword;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.GroupBox groupBoxResult;
        private System.Windows.Forms.DataGridView dgvResult;
        private System.Windows.Forms.Label lbSearchCar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pbMovie;
        private System.Windows.Forms.RichTextBox rtxtSpotSummary;
        private AxWMPLib.AxWindowsMediaPlayer axWMPTrailer;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbGenre;
        private dbMovieForRentDataSet dbMovieForRentDataSet;
        private System.Windows.Forms.BindingSource gENREBindingSource;
        private dbMovieForRentDataSetTableAdapters.GENRETableAdapter gENRETableAdapter;
        private System.Windows.Forms.ToolStrip fillByToolStrip;
        private System.Windows.Forms.ToolStripButton fillByToolStripButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMovieName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDirector;
        private System.Windows.Forms.DataGridViewTextBoxColumn colGenre;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMovieID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colReleaseYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLength;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIMDB;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSpotSummary;
        private System.Windows.Forms.DataGridViewTextBoxColumn colImagePath;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTrailerPath;
        private dbMovieForRentDataSet dbMovieForRentDataSet1;
        private dbMovieForRentDataSetTableAdapters.GENRETableAdapter genreTableAdapter1;
        private dbMovieForRentDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
    }
}

