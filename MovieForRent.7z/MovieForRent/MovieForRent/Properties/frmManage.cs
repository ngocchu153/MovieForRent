﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;


namespace MovieForRent
{
    public partial class frmManage : Form
    {
        DataGridViewRow currRow;

        public frmManage()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            frmSearchForCustomer.SearchNFillGenres("SELECT MOVIE.* FROM MOVIE", dgvResult);
        //tab Movie 
            this.gENRETableAdapter.Fill(this.dbMovieForRentDataSet.GENRE);
            txtKeyword.ForeColor = Color.Gray;

            //fill genre combobox
            DataRow dr = dbMovieForRentDataSet.Tables[0].NewRow();
            dr["GenreName"] = "All Genre";
            dr["GenreID"] = 0;
            dbMovieForRentDataSet.Tables[0].Rows.InsertAt(dr, 0);
            cbSearchGenre.SelectedIndex = 0;
            
            // fill CheckListBox GENRES
            SqlConnection cnn = new SqlConnection();
            frmSearchForCustomer.connect(cnn);
            SqlCommand cmd = new SqlCommand("SELECT GENREID,GENRENAME FROM GENRE ", cnn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            //tabGenre.datagridView
            dgvgenre.DataSource = dt;

            foreach (DataRow row in dt.Rows)
            {
                ((ListBox)checkedListBox1).DataSource = dt;
                ((ListBox)checkedListBox1).DisplayMember = "GenreName";
                ((ListBox)checkedListBox1).ValueMember = "GenreID";
            }
        }

       
        
        private void txtKeyword_Leave(object sender, EventArgs e)
        {
            if (txtKeyword.Text.Equals(null) == true || txtKeyword.Text.Equals("") == true)
            {
                txtKeyword.Text = "Enter Movie Name or Director";
                txtKeyword.ForeColor = Color.Gray;
            }
        }

        private void txtKeyword_Enter(object sender, EventArgs e)
        {
            if (txtKeyword.Text.Equals("Enter Movie Name or Director") == true)
            {
                txtKeyword.Text = "";
                txtKeyword.ForeColor = Color.Black;
            }
            Cursor.Current = Cursors.IBeam;
        }

        private void btnChooseImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = "Image Files (.png; .jpg )|*.png; *.jpg";
            openDialog.ShowDialog();
            string sFileName = openDialog.FileName;
            if (sFileName != "")
                txtImage.Text = Path.GetFullPath(sFileName);
            return;
        }

        private void btnChoosTrailerPath_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = "Video Files (.mp4 )|*.mp4";
            openDialog.ShowDialog();
            string sFileName = openDialog.FileName;
            if (sFileName != "")
                txtTrailer.Text = Path.GetFullPath(sFileName);
            return;
        }

        private void tabMovie_Clear()
        {
            txtMovieID.Text = "AUTO";
            txtMovieName.Text = txtDirector.Text = txtLength.Text = txtIMDB.Text = txtReleaseYear.Text = txtImage.Text = txtTrailer.Text = rtxtSpotSummary.Text = "";
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
                checkedListBox1.SetItemChecked(i, false);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            frmSearchForCustomer.search(txtKeyword, cbSearchGenre, dgvResult);
            
        }
        
        private void btnClear_Click(object sender, EventArgs e)
        {
            tabMovie_Clear();
            
        }
        
        private void dgvResult_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row;
                row = this.dgvResult.Rows[e.RowIndex];
                txtMovieID.Text = row.Cells["colMovieID"].Value.ToString();
                txtMovieName.Text = row.Cells["colMovieNAME"].Value.ToString();
                txtDirector.Text = row.Cells["colDirector"].Value.ToString();
                txtLength.Text = row.Cells["colLength"].Value.ToString();
                txtIMDB.Text = row.Cells["colIMDB"].Value.ToString();
                txtReleaseYear.Text = row.Cells["colReleaseYear"].Value.ToString();
                txtImage.Text = row.Cells["colImagePath"].Value.ToString();
                txtTrailer.Text = row.Cells["colTrailerPath"].Value.ToString();
                rtxtSpotSummary.Text = row.Cells["colSpotSummary"].Value.ToString();


                SqlConnection cnn = new SqlConnection();
                frmSearchForCustomer.connect(cnn);
                SqlCommand cmd = new SqlCommand("SELECT GENREID FROM MOVIE_GENRES WHERE MOVIEID = '" + row.Cells["colMovieID"].Value.ToString() + "'", cnn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                List<int> list = new List<int>();

                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(Convert.ToInt32(dr["GENREID"]));
                }
                for (int i = 0; i < checkedListBox1.Items.Count; i++)
                {

                    int value = 0;

                    DataRowView view = checkedListBox1.Items[i] as DataRowView;
                    value = (int)view["GenreID"];
                    if (list.Contains(value))
                        checkedListBox1.SetItemChecked(i, true);
                    else
                        checkedListBox1.SetItemChecked(i, false);
                }

            }
        }
        

        //private void btnUpdateMovie_Genres_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        SqlConnection connection = new SqlConnection();
        //        frmSearchForCustomer.connect(connection);
        //        string deleteCmd = "DELETE FROM MOVIE_GENRES WHERE MOVIEID = '"+ currRow.Cells["colMGMovieID"].Value.ToString() + "'";
        //        SqlCommand cmd = new SqlCommand(deleteCmd, connection);
        //        cmd.ExecuteNonQuery();

        //        for (int i = 0; i < checkedListBox1.Items.Count; i++)
        //        {
        //            if (checkedListBox1.GetItemChecked(i))
        //            {
        //                DataRowView rowID = checkedListBox1.Items[i] as DataRowView;
        //                string IDvalue = rowID["GenreID"].ToString();
        //                string addCmd = "INSERT INTO MOVIE_GENRES VALUES ('" + currRow.Cells["colMGMovieID"].Value.ToString() + "', '" + IDvalue + "')";
        //                cmd = new SqlCommand(addCmd, connection);
        //                cmd.ExecuteNonQuery();
        //            }
        //        }

                
        //        connection.Close();
        //        MessageBox.Show("Updated");
        //    }
        //    catch 
        //    {
        //        MessageBox.Show("Choose a row to edit! ");
        //    }
        //    finally
        //    {
        //    }
        //}

        private void btnAddMovie_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = new SqlConnection();
                frmSearchForCustomer.connect(cnn);
                string addCommand = "insert into MOVIE(NAME,RELEASEYEAR,DIRECTOR,LENGTH,IMDB,SPOTSUMMARY,IMAGEPATH,TRAILERPATH)values(@NAME,@RELEASEYEAR,@DIRECTOR,@LENGTH,@IMDB,@SPOTSUMMARY,@IMAGEPATH,@TRAILERPATH)";
                SqlCommand cmd = new SqlCommand(addCommand, cnn);

                cmd.Parameters.AddWithValue("@NAME", txtMovieName.Text);
                cmd.Parameters.AddWithValue("@RELEASEYEAR", int.Parse(txtReleaseYear.Text));
                cmd.Parameters.AddWithValue("@DIRECTOR", txtDirector.Text);
                cmd.Parameters.AddWithValue("@LENGTH", int.Parse(txtLength.Text));
                cmd.Parameters.AddWithValue("@IMDB", decimal.Parse(txtIMDB.Text));
                cmd.Parameters.AddWithValue("@SPOTSUMMARY", rtxtSpotSummary.Text);
                cmd.Parameters.AddWithValue("@IMAGEPATH", txtImage.Text);
                cmd.Parameters.AddWithValue("@TRAILERPATH", txtTrailer.Text);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Added");
                cnn.Close();
                tabMovie_Clear();
            }
            catch
            {
                MessageBox.Show("Failed");
            }
            finally
            {
                frmSearchForCustomer.SearchNFillGenres("SELECT MOVIE.* FROM MOVIE", dgvResult);
            }

        }

        private void btnDeleteMovie_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = new SqlConnection();
                frmSearchForCustomer.connect(cnn);
                string deleteCmd = "delete from MOVIE where MOVIEID = '" + txtMovieID.Text + "'";
                SqlCommand cmd = new SqlCommand(deleteCmd, cnn);
                DialogResult result = MessageBox.Show("Are you sure want to delete?", "!!!", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (result == DialogResult.OK)
                    cmd.ExecuteNonQuery();
                MessageBox.Show("Movie deleted");
                cnn.Close();
                tabMovie_Clear();

            }
            catch
            {
                MessageBox.Show("Failed");
            }
            finally
            {
                frmSearchForCustomer.SearchNFillGenres("SELECT MOVIE.* FROM MOVIE", dgvResult);
            }
        }

        private void btnUpdateMovie_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = new SqlConnection();
                frmSearchForCustomer.connect(cnn);
                string editCmd = "UPDATE MOVIE set NAME=@NAME,RELEASEYEAR=@RELEASEYEAR,DIRECTOR=@DIRECTOR,LENGTH=@LENGTH,IMDB=@IMDB,SPOTSUMMARY=@SPOTSUMMARY,IMAGEPATH=@IMAGEPATH,TRAILERPATH=@TRAILERPATH where MOVIEID='" + txtMovieID.Text + "'";
                SqlCommand cmd = new SqlCommand(editCmd, cnn);
                cmd.Parameters.AddWithValue("@NAME", txtMovieName.Text);
                cmd.Parameters.AddWithValue("@RELEASEYEAR", int.Parse(txtReleaseYear.Text));
                cmd.Parameters.AddWithValue("@DIRECTOR", txtDirector.Text);
                cmd.Parameters.AddWithValue("@LENGTH", int.Parse(txtLength.Text));
                cmd.Parameters.AddWithValue("@IMDB", decimal.Parse(txtIMDB.Text));
                cmd.Parameters.AddWithValue("@SPOTSUMMARY", rtxtSpotSummary.Text);
                cmd.Parameters.AddWithValue("@IMAGEPATH", txtImage.Text);
                cmd.Parameters.AddWithValue("@TRAILERPATH", txtTrailer.Text);
                
                cmd.ExecuteNonQuery();

               // MessageBox.Show("Movie updated");
                

                SqlConnection connection = new SqlConnection();
                frmSearchForCustomer.connect(connection);
                string deleteCmd = "DELETE FROM MOVIE_GENRES WHERE MOVIEID = '" + currRow.Cells["colMovieID"].Value.ToString() + "'";
                cmd = new SqlCommand(deleteCmd, connection);
                cmd.ExecuteNonQuery();

                for (int i = 0; i < checkedListBox1.Items.Count; i++)
                {
                    if (checkedListBox1.GetItemChecked(i))
                    {
                        DataRowView rowID = checkedListBox1.Items[i] as DataRowView;
                        string IDvalue = rowID["GenreID"].ToString();
                        string addCmd = "INSERT INTO MOVIE_GENRES VALUES ('" + currRow.Cells["colMovieID"].Value.ToString() + "', '" + IDvalue + "')";
                        cmd = new SqlCommand(addCmd, connection);
                        cmd.ExecuteNonQuery();
                    }
                }
                cnn.Close();
                tabMovie_Clear();

                connection.Close();
                MessageBox.Show("Updated");

            }
            catch
            {
                MessageBox.Show("Failed");
            }
            finally
            {
                frmSearchForCustomer.SearchNFillGenres("SELECT MOVIE.* FROM MOVIE", dgvResult);
            }
        }


      

       

        private void dgvMovie_Genres_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                currRow = this.dgvMovie_Genres.Rows[e.RowIndex];
                txtMovie.Text = currRow.Cells["colMGMovieID"].Value.ToString()+ " | " + currRow.Cells["colMGMovieName"].Value.ToString();

                SqlConnection cnn = new SqlConnection();
                frmSearchForCustomer.connect(cnn);
                SqlCommand cmd = new SqlCommand("SELECT GENREID FROM MOVIE_GENRES WHERE MOVIEID = '" + currRow.Cells["colMGMovieID"].Value.ToString() + "'", cnn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                List<int> list = new List<int> ();

                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(Convert.ToInt32(dr["GENREID"]));
                }
                for (int i = 0; i < checkedListBox1.Items.Count; i++)
                {

                    int value = 0;

                    DataRowView view = checkedListBox1.Items[i] as DataRowView;
                    value = (int)view["GenreID"];
                    if (list.Contains(value))
                        checkedListBox1.SetItemChecked(i, true);
                    else
                        checkedListBox1.SetItemChecked(i, false);
                }
            }
        }

        private void dgvgenre_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row;
                row = this.dgvgenre.Rows[e.RowIndex];
                txtGenreID.Text = row.Cells["GENREID"].Value.ToString();
                txtGenreName.Text = row.Cells["GENRENAME"].Value.ToString();
            }
        }

        private void tabGenre_Clear()
        {
            txtGenreID.Text = "AUTO";
            txtGenreName.Text = "";
        }

        private void btnAddgenre_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = new SqlConnection();
                frmSearchForCustomer.connect(cnn);
                string addCommand = "insert into Genre(GENRENAME)values(@GENREID)";
                SqlCommand cmd = new SqlCommand(addCommand, cnn);

                cmd.Parameters.AddWithValue("@GENREID", txtGenreID.Text);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Added");
                cnn.Close();
                tabGenre_Clear();

            }
            catch
            {
                MessageBox.Show("Failed");
            }
            finally
            {
                frmSearchForCustomer.SearchNFillGenres("SELECT GENRE.* FROM GENRE", dgvgenre);
            }
        }

        private void btnDeletegenre_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = new SqlConnection();
                frmSearchForCustomer.connect(cnn);
                string deleteCmd = "delete from GENRE where GENREID = '" + txtGenreID.Text + "'";
                SqlCommand cmd = new SqlCommand(deleteCmd, cnn);
                DialogResult result = MessageBox.Show("Are you sure want to delete?", "!!!", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (result == DialogResult.OK)
                    cmd.ExecuteNonQuery();
                MessageBox.Show("Genre deleted");
                cnn.Close();
                tabGenre_Clear();

            }
            catch
            {
                MessageBox.Show("Failed");
            }
            finally
            {
                frmSearchForCustomer.SearchNFillGenres("SELECT GENRE.* FROM GENRE", dgvgenre);
            }
        }

        private void btnUpdategenre_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = new SqlConnection();
                frmSearchForCustomer.connect(cnn);
                string editCmd = "UPDATE MOVIE set GENRENAME =@GENRENAME     where GENREID='" + txtGenreID.Text + "'";
                SqlCommand cmd = new SqlCommand(editCmd, cnn);
                cmd.Parameters.AddWithValue("@GENRENAME", txtGenreName.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Genre updated");
                cnn.Close();
                tabGenre_Clear();

            }
            catch
            {
                MessageBox.Show("Failed");
            }
            finally
            {
                frmSearchForCustomer.SearchNFillGenres("SELECT GENRE.* FROM GENRE", dgvgenre);
            }
        }
        
    }
}
