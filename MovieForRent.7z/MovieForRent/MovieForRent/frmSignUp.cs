﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MovieForRent
{
    public partial class frmSignUp : Form
    {
        public frmSignUp()
        {
            InitializeComponent();
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            if (txtPassword.Text == ""||txtRePassword.Text=="" || txtUsername.Text == "" || cbType.Text == "")
            {
                MessageBox.Show("Please Enter full Information");
                return;
            }
            if(txtPassword.Text != txtRePassword.Text)
            {
                MessageBox.Show("ReEnter Your Password! ");
                txtPassword.Text = "";
                txtRePassword.Text = "";
                return;
            }
            string cnnString = "Data Source=DESKTOP-M59GT3U\\SQLEXPRESS; Initial Catalog = dbMovieForRent; Integrated Security=true;";
            using (SqlConnection conn = new SqlConnection(cnnString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("INSERT INTO ACCOUNT VALUES (@USERNAME,@PASSWORD,@USERTYPE)", conn))
                {

                    cmd.Parameters.AddWithValue("@USERNAME", txtUsername.Text);
                    cmd.Parameters.AddWithValue("@PASSWORD", txtPassword.Text);
                    cmd.Parameters.AddWithValue("@USERTYPE", cbType.Text);

                    try
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Succeeded! ");
                    }
                    catch
                    {
                        MessageBox.Show("Failed! ");
                    }

                }
            }
        }
    }
}
