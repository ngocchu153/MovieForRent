﻿namespace MovieForRent
{
    partial class frmStaffMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmStaffMenu));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnTransactions = new System.Windows.Forms.Button();
            this.btnDiscsReceiptIssue = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logOutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(257, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(74, 24);
            this.logOutToolStripMenuItem.Text = "Log Out";
            this.logOutToolStripMenuItem.Click += new System.EventHandler(this.logOutToolStripMenuItem_Click);
            // 
            // btnTransactions
            // 
            this.btnTransactions.BackColor = System.Drawing.Color.White;
            this.btnTransactions.Image = ((System.Drawing.Image)(resources.GetObject("btnTransactions.Image")));
            this.btnTransactions.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTransactions.Location = new System.Drawing.Point(47, 126);
            this.btnTransactions.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTransactions.Name = "btnTransactions";
            this.btnTransactions.Size = new System.Drawing.Size(163, 42);
            this.btnTransactions.TabIndex = 1;
            this.btnTransactions.Text = "Transactions";
            this.btnTransactions.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTransactions.UseVisualStyleBackColor = false;
            this.btnTransactions.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnDiscsReceiptIssue
            // 
            this.btnDiscsReceiptIssue.BackColor = System.Drawing.Color.White;
            this.btnDiscsReceiptIssue.Image = ((System.Drawing.Image)(resources.GetObject("btnDiscsReceiptIssue.Image")));
            this.btnDiscsReceiptIssue.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDiscsReceiptIssue.Location = new System.Drawing.Point(47, 62);
            this.btnDiscsReceiptIssue.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDiscsReceiptIssue.Name = "btnDiscsReceiptIssue";
            this.btnDiscsReceiptIssue.Size = new System.Drawing.Size(163, 42);
            this.btnDiscsReceiptIssue.TabIndex = 2;
            this.btnDiscsReceiptIssue.Text = "Discs Receipt/Issue";
            this.btnDiscsReceiptIssue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDiscsReceiptIssue.UseVisualStyleBackColor = false;
            this.btnDiscsReceiptIssue.Click += new System.EventHandler(this.btnDiscsReceiptIssue_Click);
            // 
            // frmStaffMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(257, 207);
            this.Controls.Add(this.btnDiscsReceiptIssue);
            this.Controls.Add(this.btnTransactions);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.Color.MidnightBlue;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmStaffMenu";
            this.Text = "Staff Menu";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
        private System.Windows.Forms.Button btnTransactions;
        private System.Windows.Forms.Button btnDiscsReceiptIssue;
    }
}