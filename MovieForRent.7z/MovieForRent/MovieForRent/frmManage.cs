﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MovieForRent
{
    public partial class frmManage : Form
    {
        public frmManage()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            frmSearchForCustomer.SearchNFillGenres("SELECT MOVIE.* FROM MOVIE", dgvResult);
        //tab Movie 
            this.gENRETableAdapter.Fill(this.dbMovieForRentDataSet.GENRE);
            txtKeyword.ForeColor = Color.Gray;

            //fill genre combobox
            DataRow dr = dbMovieForRentDataSet.Tables[0].NewRow();
            dr["GenreName"] = "None";
            dr["GenreID"] = 0;
            dbMovieForRentDataSet.Tables[0].Rows.InsertAt(dr, 0);
            cbSearchGenre.SelectedIndex = 0;

        //tab Movie_Genres
            //fill CheckListBox GENRES
            SqlConnection cnn = new SqlConnection();
            frmSearchForCustomer.connect(cnn);
            SqlCommand cmd = new SqlCommand("SELECT GENREID,GENRENAME FROM GENRE ", cnn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            foreach (DataRow row in dt.Rows)
            {
                ((ListBox)checkedListBox1).DataSource = dt;
                ((ListBox)checkedListBox1).DisplayMember = "GenreName";
                ((ListBox)checkedListBox1).ValueMember = "GenreID";
            }
            //fill dgv

            frmSearchForCustomer.SearchNFillGenres("SELECT MOVIEID, NAME FROM MOVIE", dgvMovie_Genres);

        }

        private void txtKeyword_KeyDown(object sender, KeyEventArgs e)
        {
            if (txtKeyword.Text.Equals("Enter Movie Name or Director") == true)
            {
                txtKeyword.Text = "";
                txtKeyword.ForeColor = Color.Black;
            }
        }

        private void txtKeyword_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtKeyword.Text.Equals(null) == true || txtKeyword.Text.Equals("") == true)
            {
                txtKeyword.Text = "Enter Movie Name or Director";
                txtKeyword.ForeColor = Color.Gray;
            }
        }

        private void txtKeyword_Enter(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.IBeam;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtKeyword.ForeColor == Color.Gray && int.Parse(cbSearchGenre.SelectedIndex.ToString()) == 0)
            {
                frmSearchForCustomer.SearchNFillGenres("SELECT MOVIE.* FROM MOVIE", dgvResult);
            }
            else if (txtKeyword.ForeColor == Color.Gray && int.Parse(cbSearchGenre.SelectedIndex.ToString()) > 0)
            {
                frmSearchForCustomer.SearchNFillGenres("SELECT MOVIE.* FROM MOVIE join MOVIE_GENRES ON MOVIE.MOVIEID = MOVIE_GENRES.MOVIEID WHERE GENREID = '" + cbSearchGenre.SelectedValue + "'", dgvResult);
            }
            else if (txtKeyword.ForeColor != Color.Gray && int.Parse(cbSearchGenre.SelectedIndex.ToString()) == 0)
            {
                frmSearchForCustomer.SearchNFillGenres("SELECT MOVIE.* FROM MOVIE where NAME like '%" + txtKeyword.Text + "%' OR DIRECTOR like '%" + txtKeyword.Text + "%'", dgvResult);
            }
            else if (txtKeyword.ForeColor != Color.Gray && int.Parse(cbSearchGenre.SelectedIndex.ToString()) > 0)
            {
                frmSearchForCustomer.SearchNFillGenres("SELECT MOVIE.* FROM MOVIE  join MOVIE_GENRES ON MOVIE.MOVIEID = MOVIE_GENRES.MOVIEID where (NAME like '%" + txtKeyword.Text + "%' OR DIRECTOR like '%" + txtKeyword.Text + "%') AND GENREID = '" + cbSearchGenre.SelectedValue + "'", dgvResult);
            }
            
        }

       
        private void btnClear_Click(object sender, EventArgs e)
        {

        }
        
        private void dgvResult_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row;
                row = this.dgvResult.Rows[e.RowIndex];
                txtMovieID.Text = row.Cells["colMovieID"].Value.ToString();
                txtMovieName.Text = row.Cells["colMovieNAME"].Value.ToString();
                txtDirector.Text = row.Cells["colDirector"].Value.ToString();
                txtLength.Text = row.Cells["colLength"].Value.ToString();
                txtIMDB.Text = row.Cells["colIMDB"].Value.ToString();
                txtReleaseYear.Text = row.Cells["colReleaseYear"].Value.ToString();
                txtImage.Text = row.Cells["colImagePath"].Value.ToString();
                txtTrailer.Text = row.Cells["colTrailerPath"].Value.ToString();
                rtxtSpotSummary.Text = row.Cells["colSpotSummary"].Value.ToString();

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmSearchForCustomer.SearchNFillGenres("SELECT MOVIEID, NAME FROM MOVIE", dgvMovie_Genres);

        }

        private void dgvMovie_Genres_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvMovie_Genres.Rows[e.RowIndex];
                txtMovie.Text = row.Cells["colMGMovieName"].Value.ToString();

                SqlConnection cnn = new SqlConnection();
                frmSearchForCustomer.connect(cnn);
                SqlCommand cmd = new SqlCommand("SELECT GENREID FROM MOVIE_GENRES WHERE MOVIEID = '" + row.Cells["colMGMovieID"].Value.ToString() + "'", cnn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                List<int> list = new List<int> ();

                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(Convert.ToInt32(dr["GENREID"]));
                }
                for (int i = 0; i < checkedListBox1.Items.Count; i++)
                {

                    int value = 0;

                    DataRowView view = checkedListBox1.Items[i] as DataRowView;
                    value = (int)view["GenreID"];
                    if (list.Contains(value))
                        checkedListBox1.SetItemChecked(i, true);
                    else
                        checkedListBox1.SetItemChecked(i, false);
                }
            }
        }

        private void gbCarInfomation_Enter(object sender, EventArgs e)
        {

        }
    }
}
