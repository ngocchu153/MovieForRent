﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MovieForRent
{
    public partial class frmSearchForCustomer : Form
    {
        public static void connect(SqlConnection cnn)
        {
            string connectionString = "Data Source=DESKTOP-M59GT3U\\SQLEXPRESS; Initial Catalog = dbMovieForRent; Integrated Security=true;";
            cnn.ConnectionString = connectionString;
            cnn.Open();
        }

        public frmSearchForCustomer()
        {
            InitializeComponent();
            
        }
        

        private void axWindowsMediaPlayer1_Enter(object sender, EventArgs e)
        {
            axWMPTrailer.Ctlcontrols.play();
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dbMovieForRentDataSet.GENRE' table. You can move, or remove it, as needed.
            this.gENRETableAdapter.Fill(this.dbMovieForRentDataSet.GENRE);
            cbGenre.SelectedIndex = -1;
            cbGenre.Text = ("All genre");
            txtKeyword.ForeColor = Color.Gray;

             SearchNFillGenres("SELECT MOVIE.* FROM MOVIE", dgvResult);

        }

        private void txtKeyword_MouseDown(object sender, MouseEventArgs e)
        {
            Cursor.Current = Cursors.IBeam;
        }

        private void txtKeyword_KeyDown(object sender, KeyEventArgs e)
        {
            if (txtKeyword.Text.Equals("Enter Movie Name or Director") == true)
            {
                txtKeyword.Text = "";
                txtKeyword.ForeColor = Color.Black;
            }
        }

        private void txtKeyword_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtKeyword.Text.Equals(null) == true || txtKeyword.Text.Equals("") == true)
            {
                txtKeyword.Text = "Enter Movie Name or Director";
                txtKeyword.ForeColor = Color.Gray;
            }
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.gENRETableAdapter.FillBy(this.dbMovieForRentDataSet.GENRE);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }


        public static  string getGenres(int movieID) //get all genres of a single movie and return to string
        {
            string genres = "";

            SqlConnection cnn = new SqlConnection();
            connect(cnn);

            SqlCommand cmd = new SqlCommand("SELECT GENRENAME, MOVIEID FROM MOVIE_GENRES m join GENRE g on (m.GENREID=g.GENREID) where MOVIEID = '" + movieID +"'", cnn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            
            foreach (DataRow row in dt.Rows)
                genres += row["GENRENAME"].ToString() + ", ";

            return genres;
        }

        public static void SearchNFillGenres(string sqlCommand, DataGridView dgvName)
        {
            try
            {
                SqlConnection cnn = new SqlConnection();
                connect(cnn);
                SqlCommand cmd = new SqlCommand(sqlCommand, cnn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                //add a new col into datatable and fill genres
                dt.Columns.Add("Genres", typeof(String));
                foreach (DataRow row in dt.Rows)
                {
                    if (int.Parse(row["MovieID"].ToString()) > 0)
                    {
                        row["Genres"] = getGenres(int.Parse(row["MovieID"].ToString()));
                    }
                }
                dgvName.DataSource = dt;

               // fillGenres2Dgv(dgvName, colGenreName, colMovieIDName);
            }
            catch
            {
                MessageBox.Show("Not Found ");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtKeyword.ForeColor == Color.Gray && int.Parse(cbGenre.SelectedIndex.ToString()) == -1)
            {
                SearchNFillGenres("SELECT MOVIE.* FROM MOVIE", dgvResult );
            }
            else if (txtKeyword.ForeColor == Color.Gray && int.Parse(cbGenre.SelectedIndex.ToString()) > -1)
            {
                SearchNFillGenres("SELECT MOVIE.* FROM MOVIE join MOVIE_GENRES ON MOVIE.MOVIEID = MOVIE_GENRES.MOVIEID WHERE GENREID = '" + cbGenre.SelectedValue + "'", dgvResult);
            }
            else if (txtKeyword.ForeColor != Color.Gray && int.Parse(cbGenre.SelectedIndex.ToString()) == -1)
            {
                SearchNFillGenres("SELECT MOVIE.* FROM MOVIE where NAME like '%" + txtKeyword.Text + "%' OR DIRECTOR like '%" + txtKeyword.Text + "%'", dgvResult);
            }
            else if (txtKeyword.ForeColor != Color.Gray && int.Parse(cbGenre.SelectedIndex.ToString()) > -1)
            {
                SearchNFillGenres("SELECT MOVIE.* FROM MOVIE  join MOVIE_GENRES ON MOVIE.MOVIEID = MOVIE_GENRES.MOVIEID where (NAME like '%" + txtKeyword.Text + "%' OR DIRECTOR like '%" + txtKeyword.Text + "%') AND GENREID = '" + cbGenre.SelectedValue + "'", dgvResult);
            }
        }

        private void dgvResult_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvResult.Rows[e.RowIndex];
                rtxtSpotSummary.Text = row.Cells["colSpotSummary"].Value.ToString();
                if(row.Cells["colImagePath"].Value.ToString()!="")
                    pbMovie.Image = Image.FromFile(row.Cells["colImagePath"].Value.ToString());
                axWMPTrailer.URL = row.Cells["colTrailerPath"].Value.ToString();
                axWMPTrailer.Ctlcontrols.stop();
            }
        }
    }
}
