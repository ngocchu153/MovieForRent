﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MovieForRent
{
    public partial class frmSearchForCustomer : Form
    {
        public static void connect(SqlConnection cnn)
        {
            string connectionString = "Data Source=DESKTOP-M59GT3U\\SQLEXPRESS; Initial Catalog = dbMovieForRent; Integrated Security=true;";
            cnn.ConnectionString = connectionString;
            cnn.Open();
        }

        public frmSearchForCustomer()
        {
            InitializeComponent();
            
        }
        
        

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dbMovieForRentDataSet.GENRE' table. You can move, or remove it, as needed.
            this.gENRETableAdapter.Fill(this.dbMovieForRentDataSet.GENRE);
            cbGenre.SelectedIndex = -1;
            cbGenre.Text = ("All genre");
            txtKeyword.ForeColor = Color.Gray;

             SearchNFillGenres("SELECT MOVIE.* FROM MOVIE", dgvResult);
            DataRow dr = dbMovieForRentDataSet.Tables[0].NewRow();
            dr["GenreName"] = "All Genre";
            dr["GenreID"] = 0;
            dbMovieForRentDataSet.Tables[0].Rows.InsertAt(dr, 0);
            cbGenre.SelectedIndex = 0;
            this.Size = new Size(565, 570);
        }

        private void txtKeyword_Enter(object sender, EventArgs e)
        {
            if (txtKeyword.Text.Equals("Enter Movie Name or Director") == true)
                {
                    txtKeyword.Text = "";
                    txtKeyword.ForeColor = Color.Black;
                }
                 Cursor.Current = Cursors.IBeam;
        }

        private void txtKeyword_Leave(object sender, EventArgs e)
        {
            if (txtKeyword.Text.Equals(null) == true || txtKeyword.Text.Equals("") == true)
            {
                txtKeyword.Text = "Enter Movie Name or Director";
                txtKeyword.ForeColor = Color.Gray;
            }
        }
        
        public static  string getGenres(int movieID) //get all genres of a single movie and return to string
        {
            string genres = "";

            SqlConnection cnn = new SqlConnection();
            connect(cnn);

            SqlCommand cmd = new SqlCommand("SELECT GENRENAME, MOVIEID FROM MOVIE_GENRES m join GENRE g on (m.GENREID=g.GENREID) where MOVIEID = '" + movieID +"'", cnn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            
            foreach (DataRow row in dt.Rows)
                genres += row["GENRENAME"].ToString() + ", ";

            return genres;
        }

        public static void SearchNFillGenres(string sqlCommand, DataGridView dgvName)
        {
            //try
            {
                SqlConnection cnn = new SqlConnection();
                connect(cnn);
                SqlCommand cmd = new SqlCommand(sqlCommand, cnn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                //add a new col into datatable and fill genres
                dt.Columns.Add("Genres", typeof(String));
                foreach (DataRow row in dt.Rows)
                {
                    if (int.Parse(row["MovieID"].ToString()) > 0)
                    {
                        row["Genres"] = getGenres(int.Parse(row["MovieID"].ToString()));
                    }
                }
                dgvName.DataSource = dt;

           }
        //    catch
        //    {
        //        MessageBox.Show("Not Found ");
        //    }
        }

        public static void search(TextBox textboxKeyword_Name, ComboBox comboboxGenre_Name, DataGridView DGVtoDisplay)
        {
            if (textboxKeyword_Name.ForeColor == Color.Gray && int.Parse(comboboxGenre_Name.SelectedIndex.ToString()) == 0)
            {
                SearchNFillGenres("SELECT MOVIE.* FROM MOVIE", DGVtoDisplay);
            }
            else if (textboxKeyword_Name.ForeColor == Color.Gray && int.Parse(comboboxGenre_Name.SelectedIndex.ToString()) > 0)
            {
                SearchNFillGenres("SELECT MOVIE.* FROM MOVIE join MOVIE_GENRES ON MOVIE.MOVIEID = MOVIE_GENRES.MOVIEID WHERE GENREID = '" + comboboxGenre_Name.SelectedValue + "'", DGVtoDisplay);
            }
            else if (textboxKeyword_Name.ForeColor != Color.Gray && int.Parse(comboboxGenre_Name.SelectedIndex.ToString()) == 0)
            {
                SearchNFillGenres("SELECT MOVIE.* FROM MOVIE where NAME like '%" + textboxKeyword_Name.Text + "%' OR DIRECTOR like '%" + textboxKeyword_Name.Text + "%'", DGVtoDisplay);
            }
            else if (textboxKeyword_Name.ForeColor != Color.Gray && int.Parse(comboboxGenre_Name.SelectedIndex.ToString()) > 0)
            {
                SearchNFillGenres("SELECT MOVIE.* FROM MOVIE  join MOVIE_GENRES ON MOVIE.MOVIEID = MOVIE_GENRES.MOVIEID where (NAME like '%" + textboxKeyword_Name.Text + "%' OR DIRECTOR like '%" + textboxKeyword_Name.Text + "%') AND GENREID = '" + comboboxGenre_Name.SelectedValue + "'", DGVtoDisplay);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            search(txtKeyword, cbGenre, dgvResult);
            if (dgvResult.Rows.Count == 0)
            {
                MessageBox.Show("No movie found!");
            }
        }

        private void dgvResult_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
            if (e.RowIndex >= 0)
            {
                this.Size = new Size(1109, 570);
                DataGridViewRow row = this.dgvResult.Rows[e.RowIndex];
                rtxtSpotSummary.Text = row.Cells["colSpotSummary"].Value.ToString();
                if(row.Cells["colImagePath"].Value.ToString()!="")
                    pbMovie.Image = Image.FromFile(row.Cells["colImagePath"].Value.ToString());
                else
                    pbMovie.Image = null;
                if (row.Cells["colTrailerPath"].Value.ToString() == "" || string.IsNullOrEmpty(row.Cells["colTrailerPath"].Value.ToString()))
                    axWMPTrailer.uiMode = "None";
                else
                {
                    axWMPTrailer.uiMode = "mini";
                    axWMPTrailer.URL = row.Cells["colTrailerPath"].Value.ToString();
                }
                axWMPTrailer.Ctlcontrols.stop();
                lbIMDB.Text = row.Cells["colIMDB"].Value.ToString();
                lbReleaseYear.Text = row.Cells["colReleaseYear"].Value.ToString();
                lbLength.Text = row.Cells["colLength"].Value.ToString();
            }
        }

        private void frmSearchForCustomer_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmLogin newFrmLogin = new frmLogin();
            newFrmLogin.Show();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
