﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MovieForRent
{
    public partial class frmTransactionDetail : Form
    {
        string tempStatus2Check = ""; //tempStatus of selected transaction

        public frmTransactionDetail()
        {
            InitializeComponent();
        }

        private void frmTransactionDetail_Load(object sender, EventArgs e)
        { 
            // TODO: This line of code loads data into the 'dbMovieForRentDataSet1.TRANSACTIONS' table. You can move, or remove it, as needed.
            this.tRANSACTIONSTableAdapter.Fill(this.dbMovieForRentDataSet1.TRANSACTIONS);

        }
        
        

        private void dgvTransaction_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) {
                DataGridViewRow row;
                row = this.dgvTransaction.Rows[e.RowIndex];

                txtTransactionID.Text = row.Cells["TRANSACTIONID"].Value.ToString();
                dtpReceivedDate.Value = (DateTime)row.Cells["RECEIVEDDATE"].Value ;
                dtpDueDate.Value = (DateTime)row.Cells["DUEDATE"].Value;
                tempStatus2Check = row.Cells["STATUS"].Value.ToString();

                if (row.Cells["STATUS"].Value.ToString() == "")
                {
                    cbIsReceived.SelectedIndex = cbIsReturned.SelectedIndex = 0;
                }
                else if (row.Cells["STATUS"].Value.ToString() == "RECEIVED")
                {
                    cbIsReceived.SelectedIndex = 1;
                    cbIsReturned.SelectedIndex = 0;
                }
                else if (row.Cells["STATUS"].Value.ToString() == "RETURNED")
                {
                    cbIsReceived.SelectedIndex = 1;
                    cbIsReturned.SelectedIndex = 1;
                }

            }
        }
        
        private int receiveMovie(string transactionID)
        {
            string selectMovieID = "SELECT MOVIEID FROM TRANSACTIONS WHERE TRANSACTIONID = '" + transactionID + "'";
            SqlConnection connection = new SqlConnection();
            frmSearchForCustomer.connect(connection);
           
            SqlCommand cmd = new SqlCommand(selectMovieID, connection);
            string movieID=(cmd.ExecuteScalar().ToString());

            string updateQuantity = "UPDATE INVENTORY set QUANTITY = (QUANTITY-1) WHERE (QUANTITY-1 >=0) and MOVIEID = '" + movieID + "'";

            cmd = new SqlCommand(updateQuantity, connection);
            if (cmd.ExecuteNonQuery() < 1)
            {
                MessageBox.Show("Your movie is not available! ");
                return 0;
            }
            cmd.ExecuteNonQuery();
            connection.Close();
            return 1;
        }

        private int returnMovie(string transactionID)
        {
            string selectMovieID = "SELECT MOVIEID FROM TRANSACTIONS WHERE TRANSACTIONID = '" + transactionID + "'";
            SqlConnection connection = new SqlConnection();
            frmSearchForCustomer.connect(connection);

            SqlCommand cmd = new SqlCommand(selectMovieID, connection);
            string movieID = (cmd.ExecuteScalar().ToString());

            string updateQuantity = "UPDATE INVENTORY set QUANTITY = (QUANTITY+1) WHERE MOVIEID = '" + movieID + "'";
            cmd = new SqlCommand(updateQuantity, connection);
            cmd.ExecuteNonQuery();
            connection.Close();
            return 1;
        }
        
        private void frm_Clear()
        {
            
            cbIsReceived.SelectedIndex = cbIsReturned.SelectedIndex = -1;
            dtpDueDate.Value = dtpReceivedDate.Value = DateTime.Now;
        }

        private void btnTransUpdate_Click(object sender, EventArgs e)
        {
            if (txtTransactionID.Text != "" || !string.IsNullOrEmpty(txtTransactionID.Text))
            {
                //try
                {
                    SqlConnection cnn = new SqlConnection();
                    frmSearchForCustomer.connect(cnn);
                    
                    string status = "";     //set status base on comboboxes RETURED n RECEIVED
                    if (cbIsReceived.SelectedIndex==1) {
                        status = "RECEIVED";
                        if (cbIsReturned.SelectedIndex==1)
                            {
                                status = "RETURNED";
                            }
                    }
                    

                    string editCmd = "UPDATE TRANSACTIONS set RECEIVEDDATE = @RECEIVEDDATE, DUEDATE = @DUEDATE, STATUS = @STATUS where TRANSACTIONID='" + txtTransactionID.Text + "'";
                    SqlCommand cmd = new SqlCommand(editCmd, cnn);
                    cmd.Parameters.AddWithValue("@RECEIVEDDATE", dtpReceivedDate.Value);
                    cmd.Parameters.AddWithValue("@DUEDATE", dtpDueDate.Value);
                    cmd.Parameters.AddWithValue("@STATUS", status);

                    cmd.ExecuteNonQuery();

                    if (tempStatus2Check != status)      //if status changed -> update quantity
                    {
                        if (tempStatus2Check == "" && status == "RECEIVED")
                            if (receiveMovie(txtTransactionID.Text) == 0) return;
                        if (tempStatus2Check == "RECEIVED" && status == "RETURNED")
                                returnMovie(txtTransactionID.Text);
                        
                    }

                    MessageBox.Show("Transaction's detail updated");
                    cnn.Close();
                    frmTransactionDetail_Load(sender, e);
                    frm_Clear();
                }
                //catch
                //{
                //    MessageBox.Show("Failed");
                //}
                //finally
                //{

                //}
            }
            else
                MessageBox.Show("Choose a transaction! ");
        }

     

        private void cbIsReceived_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbIsReceived.SelectedIndex == 0)
            {
                cbIsReturned.SelectedIndex = 0;
            }
        }

        private void cbIsReturned_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbIsReturned.SelectedIndex == 1)
            {
                cbIsReceived.SelectedIndex = 1;
                cbIsReceived.Enabled = false;
            }
            else
                cbIsReceived.Enabled = true;
        }
        
    }
}
