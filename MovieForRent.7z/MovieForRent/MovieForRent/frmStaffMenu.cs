﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieForRent
{
    public partial class frmStaffMenu : Form
    {
        public frmStaffMenu()
        {
            InitializeComponent();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmLogin newFrmLogin = new frmLogin();
            newFrmLogin.Show();
        }

        private void btnDiscsReceiptIssue_Click(object sender, EventArgs e)
        {
            frmLogin newFrmLogin = new frmLogin();
            newFrmLogin.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmIssueReciept newFrm = new frmIssueReciept();
            newFrm.Show();
        }
    }
}
