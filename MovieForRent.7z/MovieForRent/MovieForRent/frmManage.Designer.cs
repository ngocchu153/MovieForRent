﻿namespace MovieForRent
{
    partial class frmManage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtImage = new System.Windows.Forms.TextBox();
            this.gbCarInfomation = new System.Windows.Forms.GroupBox();
            this.Summary = new System.Windows.Forms.Label();
            this.rtxtSpotSummary = new System.Windows.Forms.RichTextBox();
            this.txtDirector = new System.Windows.Forms.TextBox();
            this.txtTrailer = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn = new System.Windows.Forms.Button();
            this.btnDeleteMovie = new System.Windows.Forms.Button();
            this.btnAddMovie = new System.Windows.Forms.Button();
            this.btnUpdateMovie = new System.Windows.Forms.Button();
            this.btnChooseImage = new System.Windows.Forms.Button();
            this.txtMovieName = new System.Windows.Forms.TextBox();
            this.lbMovieName = new System.Windows.Forms.Label();
            this.txtIMDB = new System.Windows.Forms.TextBox();
            this.lbIMDB = new System.Windows.Forms.Label();
            this.txtLength = new System.Windows.Forms.TextBox();
            this.lbLength = new System.Windows.Forms.Label();
            this.txtReleaseYear = new System.Windows.Forms.TextBox();
            this.txtMovieID = new System.Windows.Forms.TextBox();
            this.lbDirector = new System.Windows.Forms.Label();
            this.lbReleaseYear = new System.Windows.Forms.Label();
            this.lbImage = new System.Windows.Forms.Label();
            this.lbMovieID = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dgvgenre = new System.Windows.Forms.DataGridView();
            this.gENREIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gENRENAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gENREBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dbMovieForRentDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dbMovieForRentDataSet = new MovieForRent.dbMovieForRentDataSet();
            this.lbGenreName = new System.Windows.Forms.Label();
            this.lbGenreID = new System.Windows.Forms.Label();
            this.gbFunctions = new System.Windows.Forms.GroupBox();
            this.btnDeletegenre = new System.Windows.Forms.Button();
            this.btnAddgenre = new System.Windows.Forms.Button();
            this.btnUpdategenre = new System.Windows.Forms.Button();
            this.txtManuCode = new System.Windows.Forms.TextBox();
            this.txtManuName = new System.Windows.Forms.TextBox();
            this.gbGenreInfo = new System.Windows.Forms.GroupBox();
            this.tabGenre = new System.Windows.Forms.TabPage();
            this.lbManagegenre = new System.Windows.Forms.Label();
            this.gbgenre = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.gbMovie_Genres = new System.Windows.Forms.GroupBox();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.txtMovie = new System.Windows.Forms.TextBox();
            this.btnUpdateCarSpecs = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.gbListMovie_Genres = new System.Windows.Forms.GroupBox();
            this.dgvMovie_Genres = new System.Windows.Forms.DataGridView();
            this.colMGMovieName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMGGenres = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMGMovieID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabMovie_Genres = new System.Windows.Forms.TabPage();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tabMovie = new System.Windows.Forms.TabPage();
            this.cbSearchGenre = new System.Windows.Forms.ComboBox();
            this.txtKeyword = new System.Windows.Forms.TextBox();
            this.groupBoxResult = new System.Windows.Forms.GroupBox();
            this.dgvResult = new System.Windows.Forms.DataGridView();
            this.colMovieID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMovieName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDirector = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGenre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colReleaseYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLength = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIMDB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSpotSummary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colImagePath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTrailerPath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.gENRETableAdapter = new MovieForRent.dbMovieForRentDataSetTableAdapters.GENRETableAdapter();
            this.gbCarInfomation.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvgenre)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gENREBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet)).BeginInit();
            this.gbFunctions.SuspendLayout();
            this.gbGenreInfo.SuspendLayout();
            this.tabGenre.SuspendLayout();
            this.gbgenre.SuspendLayout();
            this.gbMovie_Genres.SuspendLayout();
            this.gbListMovie_Genres.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMovie_Genres)).BeginInit();
            this.tabMovie_Genres.SuspendLayout();
            this.tabMovie.SuspendLayout();
            this.groupBoxResult.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).BeginInit();
            this.tabControl.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtImage
            // 
            this.txtImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtImage.Location = new System.Drawing.Point(383, 85);
            this.txtImage.Name = "txtImage";
            this.txtImage.Size = new System.Drawing.Size(135, 22);
            this.txtImage.TabIndex = 16;
            // 
            // gbCarInfomation
            // 
            this.gbCarInfomation.Controls.Add(this.Summary);
            this.gbCarInfomation.Controls.Add(this.rtxtSpotSummary);
            this.gbCarInfomation.Controls.Add(this.txtDirector);
            this.gbCarInfomation.Controls.Add(this.txtTrailer);
            this.gbCarInfomation.Controls.Add(this.btnClear);
            this.gbCarInfomation.Controls.Add(this.button2);
            this.gbCarInfomation.Controls.Add(this.label1);
            this.gbCarInfomation.Controls.Add(this.txtImage);
            this.gbCarInfomation.Controls.Add(this.groupBox1);
            this.gbCarInfomation.Controls.Add(this.btnChooseImage);
            this.gbCarInfomation.Controls.Add(this.txtMovieName);
            this.gbCarInfomation.Controls.Add(this.lbMovieName);
            this.gbCarInfomation.Controls.Add(this.txtIMDB);
            this.gbCarInfomation.Controls.Add(this.lbIMDB);
            this.gbCarInfomation.Controls.Add(this.txtLength);
            this.gbCarInfomation.Controls.Add(this.lbLength);
            this.gbCarInfomation.Controls.Add(this.txtReleaseYear);
            this.gbCarInfomation.Controls.Add(this.txtMovieID);
            this.gbCarInfomation.Controls.Add(this.lbDirector);
            this.gbCarInfomation.Controls.Add(this.lbReleaseYear);
            this.gbCarInfomation.Controls.Add(this.lbImage);
            this.gbCarInfomation.Controls.Add(this.lbMovieID);
            this.gbCarInfomation.Location = new System.Drawing.Point(46, 74);
            this.gbCarInfomation.Name = "gbCarInfomation";
            this.gbCarInfomation.Size = new System.Drawing.Size(688, 230);
            this.gbCarInfomation.TabIndex = 14;
            this.gbCarInfomation.TabStop = false;
            this.gbCarInfomation.Text = "Cars Information";
            this.gbCarInfomation.Enter += new System.EventHandler(this.gbCarInfomation_Enter);
            // 
            // Summary
            // 
            this.Summary.AutoSize = true;
            this.Summary.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Summary.Location = new System.Drawing.Point(46, 153);
            this.Summary.Name = "Summary";
            this.Summary.Size = new System.Drawing.Size(45, 16);
            this.Summary.TabIndex = 22;
            this.Summary.Text = "label6";
            // 
            // rtxtSpotSummary
            // 
            this.rtxtSpotSummary.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtxtSpotSummary.Location = new System.Drawing.Point(107, 145);
            this.rtxtSpotSummary.Name = "rtxtSpotSummary";
            this.rtxtSpotSummary.Size = new System.Drawing.Size(408, 63);
            this.rtxtSpotSummary.TabIndex = 21;
            this.rtxtSpotSummary.Text = "";
            // 
            // txtDirector
            // 
            this.txtDirector.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDirector.Location = new System.Drawing.Point(107, 88);
            this.txtDirector.Name = "txtDirector";
            this.txtDirector.Size = new System.Drawing.Size(135, 22);
            this.txtDirector.TabIndex = 20;
            // 
            // txtTrailer
            // 
            this.txtTrailer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTrailer.Location = new System.Drawing.Point(383, 114);
            this.txtTrailer.Name = "txtTrailer";
            this.txtTrailer.Size = new System.Drawing.Size(135, 22);
            this.txtTrailer.TabIndex = 19;
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClear.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnClear.Location = new System.Drawing.Point(587, 12);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(58, 26);
            this.btnClear.TabIndex = 9;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // button2
            // 
            this.button2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button2.Location = new System.Drawing.Point(524, 114);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(24, 23);
            this.button2.TabIndex = 18;
            this.button2.Text = "...";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(317, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 16);
            this.label1.TabIndex = 17;
            this.label1.Text = "Trailer:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn);
            this.groupBox1.Controls.Add(this.btnDeleteMovie);
            this.groupBox1.Controls.Add(this.btnAddMovie);
            this.groupBox1.Controls.Add(this.btnUpdateMovie);
            this.groupBox1.Location = new System.Drawing.Point(559, 44);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(113, 164);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Functions";
            // 
            // btn
            // 
            this.btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn.Location = new System.Drawing.Point(28, 119);
            this.btn.Name = "btn";
            this.btn.Size = new System.Drawing.Size(58, 26);
            this.btn.TabIndex = 9;
            this.btn.Text = "Genre";
            this.btn.UseVisualStyleBackColor = true;
            // 
            // btnDeleteMovie
            // 
            this.btnDeleteMovie.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteMovie.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDeleteMovie.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnDeleteMovie.Location = new System.Drawing.Point(28, 54);
            this.btnDeleteMovie.Name = "btnDeleteMovie";
            this.btnDeleteMovie.Size = new System.Drawing.Size(58, 24);
            this.btnDeleteMovie.TabIndex = 7;
            this.btnDeleteMovie.Text = "Delete";
            this.btnDeleteMovie.UseVisualStyleBackColor = true;
            // 
            // btnAddMovie
            // 
            this.btnAddMovie.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddMovie.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddMovie.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnAddMovie.Location = new System.Drawing.Point(28, 24);
            this.btnAddMovie.Name = "btnAddMovie";
            this.btnAddMovie.Size = new System.Drawing.Size(58, 24);
            this.btnAddMovie.TabIndex = 6;
            this.btnAddMovie.Text = "Add";
            this.btnAddMovie.UseVisualStyleBackColor = true;
            // 
            // btnUpdateMovie
            // 
            this.btnUpdateMovie.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateMovie.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUpdateMovie.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnUpdateMovie.Location = new System.Drawing.Point(28, 87);
            this.btnUpdateMovie.Name = "btnUpdateMovie";
            this.btnUpdateMovie.Size = new System.Drawing.Size(58, 24);
            this.btnUpdateMovie.TabIndex = 8;
            this.btnUpdateMovie.Text = "Update";
            this.btnUpdateMovie.UseVisualStyleBackColor = true;
            // 
            // btnChooseImage
            // 
            this.btnChooseImage.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnChooseImage.Location = new System.Drawing.Point(524, 85);
            this.btnChooseImage.Name = "btnChooseImage";
            this.btnChooseImage.Size = new System.Drawing.Size(24, 23);
            this.btnChooseImage.TabIndex = 14;
            this.btnChooseImage.Text = "...";
            this.btnChooseImage.UseVisualStyleBackColor = true;
            // 
            // txtMovieName
            // 
            this.txtMovieName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMovieName.Location = new System.Drawing.Point(107, 53);
            this.txtMovieName.Name = "txtMovieName";
            this.txtMovieName.Size = new System.Drawing.Size(135, 22);
            this.txtMovieName.TabIndex = 13;
            // 
            // lbMovieName
            // 
            this.lbMovieName.AutoSize = true;
            this.lbMovieName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMovieName.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbMovieName.Location = new System.Drawing.Point(7, 58);
            this.lbMovieName.Name = "lbMovieName";
            this.lbMovieName.Size = new System.Drawing.Size(88, 16);
            this.lbMovieName.TabIndex = 12;
            this.lbMovieName.Text = "Movie Name:";
            // 
            // txtIMDB
            // 
            this.txtIMDB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIMDB.Location = new System.Drawing.Point(383, 55);
            this.txtIMDB.Name = "txtIMDB";
            this.txtIMDB.Size = new System.Drawing.Size(135, 22);
            this.txtIMDB.TabIndex = 11;
            // 
            // lbIMDB
            // 
            this.lbIMDB.AutoSize = true;
            this.lbIMDB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbIMDB.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbIMDB.Location = new System.Drawing.Point(317, 62);
            this.lbIMDB.Name = "lbIMDB";
            this.lbIMDB.Size = new System.Drawing.Size(44, 16);
            this.lbIMDB.TabIndex = 10;
            this.lbIMDB.Text = "IMDB:";
            // 
            // txtLength
            // 
            this.txtLength.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLength.Location = new System.Drawing.Point(383, 21);
            this.txtLength.Name = "txtLength";
            this.txtLength.Size = new System.Drawing.Size(135, 22);
            this.txtLength.TabIndex = 9;
            // 
            // lbLength
            // 
            this.lbLength.AutoSize = true;
            this.lbLength.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLength.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbLength.Location = new System.Drawing.Point(317, 24);
            this.lbLength.Name = "lbLength";
            this.lbLength.Size = new System.Drawing.Size(51, 16);
            this.lbLength.TabIndex = 8;
            this.lbLength.Text = "Length:";
            // 
            // txtReleaseYear
            // 
            this.txtReleaseYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReleaseYear.Location = new System.Drawing.Point(107, 117);
            this.txtReleaseYear.Name = "txtReleaseYear";
            this.txtReleaseYear.Size = new System.Drawing.Size(135, 22);
            this.txtReleaseYear.TabIndex = 6;
            // 
            // txtMovieID
            // 
            this.txtMovieID.Enabled = false;
            this.txtMovieID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMovieID.Location = new System.Drawing.Point(107, 20);
            this.txtMovieID.Name = "txtMovieID";
            this.txtMovieID.ReadOnly = true;
            this.txtMovieID.Size = new System.Drawing.Size(135, 22);
            this.txtMovieID.TabIndex = 4;
            // 
            // lbDirector
            // 
            this.lbDirector.AutoSize = true;
            this.lbDirector.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDirector.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbDirector.Location = new System.Drawing.Point(7, 92);
            this.lbDirector.Name = "lbDirector";
            this.lbDirector.Size = new System.Drawing.Size(58, 16);
            this.lbDirector.TabIndex = 3;
            this.lbDirector.Text = "Director:";
            // 
            // lbReleaseYear
            // 
            this.lbReleaseYear.AutoSize = true;
            this.lbReleaseYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbReleaseYear.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbReleaseYear.Location = new System.Drawing.Point(7, 122);
            this.lbReleaseYear.Name = "lbReleaseYear";
            this.lbReleaseYear.Size = new System.Drawing.Size(95, 16);
            this.lbReleaseYear.TabIndex = 2;
            this.lbReleaseYear.Text = "Release Year:";
            // 
            // lbImage
            // 
            this.lbImage.AutoSize = true;
            this.lbImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbImage.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbImage.Location = new System.Drawing.Point(317, 90);
            this.lbImage.Name = "lbImage";
            this.lbImage.Size = new System.Drawing.Size(49, 16);
            this.lbImage.TabIndex = 1;
            this.lbImage.Text = "Image:";
            // 
            // lbMovieID
            // 
            this.lbMovieID.AutoSize = true;
            this.lbMovieID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMovieID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbMovieID.Location = new System.Drawing.Point(7, 24);
            this.lbMovieID.Name = "lbMovieID";
            this.lbMovieID.Size = new System.Drawing.Size(61, 16);
            this.lbMovieID.TabIndex = 0;
            this.lbMovieID.Text = "MovieID:";
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSearch.Location = new System.Drawing.Point(519, 327);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 26);
            this.btnSearch.TabIndex = 18;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dgvgenre
            // 
            this.dgvgenre.AllowUserToAddRows = false;
            this.dgvgenre.AllowUserToDeleteRows = false;
            this.dgvgenre.AutoGenerateColumns = false;
            this.dgvgenre.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvgenre.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gENREIDDataGridViewTextBoxColumn,
            this.gENRENAMEDataGridViewTextBoxColumn});
            this.dgvgenre.DataSource = this.gENREBindingSource;
            this.dgvgenre.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvgenre.Location = new System.Drawing.Point(3, 18);
            this.dgvgenre.Name = "dgvgenre";
            this.dgvgenre.ReadOnly = true;
            this.dgvgenre.Size = new System.Drawing.Size(479, 206);
            this.dgvgenre.TabIndex = 0;
            // 
            // gENREIDDataGridViewTextBoxColumn
            // 
            this.gENREIDDataGridViewTextBoxColumn.DataPropertyName = "GENREID";
            this.gENREIDDataGridViewTextBoxColumn.HeaderText = "GENREID";
            this.gENREIDDataGridViewTextBoxColumn.Name = "gENREIDDataGridViewTextBoxColumn";
            this.gENREIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // gENRENAMEDataGridViewTextBoxColumn
            // 
            this.gENRENAMEDataGridViewTextBoxColumn.DataPropertyName = "GENRENAME";
            this.gENRENAMEDataGridViewTextBoxColumn.HeaderText = "GENRENAME";
            this.gENRENAMEDataGridViewTextBoxColumn.Name = "gENRENAMEDataGridViewTextBoxColumn";
            this.gENRENAMEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // gENREBindingSource
            // 
            this.gENREBindingSource.DataMember = "GENRE";
            this.gENREBindingSource.DataSource = this.dbMovieForRentDataSetBindingSource;
            // 
            // dbMovieForRentDataSetBindingSource
            // 
            this.dbMovieForRentDataSetBindingSource.DataSource = this.dbMovieForRentDataSet;
            this.dbMovieForRentDataSetBindingSource.Position = 0;
            // 
            // dbMovieForRentDataSet
            // 
            this.dbMovieForRentDataSet.DataSetName = "dbMovieForRentDataSet";
            this.dbMovieForRentDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lbGenreName
            // 
            this.lbGenreName.AutoSize = true;
            this.lbGenreName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGenreName.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbGenreName.Location = new System.Drawing.Point(33, 84);
            this.lbGenreName.Name = "lbGenreName";
            this.lbGenreName.Size = new System.Drawing.Size(88, 16);
            this.lbGenreName.TabIndex = 5;
            this.lbGenreName.Text = "Genre Name:";
            // 
            // lbGenreID
            // 
            this.lbGenreID.AutoSize = true;
            this.lbGenreID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGenreID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbGenreID.Location = new System.Drawing.Point(33, 46);
            this.lbGenreID.Name = "lbGenreID";
            this.lbGenreID.Size = new System.Drawing.Size(67, 16);
            this.lbGenreID.TabIndex = 4;
            this.lbGenreID.Text = "Genre ID: ";
            // 
            // gbFunctions
            // 
            this.gbFunctions.Controls.Add(this.btnDeletegenre);
            this.gbFunctions.Controls.Add(this.btnAddgenre);
            this.gbFunctions.Controls.Add(this.btnUpdategenre);
            this.gbFunctions.Location = new System.Drawing.Point(490, 89);
            this.gbFunctions.Name = "gbFunctions";
            this.gbFunctions.Size = new System.Drawing.Size(117, 141);
            this.gbFunctions.TabIndex = 13;
            this.gbFunctions.TabStop = false;
            this.gbFunctions.Text = "Functions";
            // 
            // btnDeletegenre
            // 
            this.btnDeletegenre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeletegenre.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDeletegenre.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnDeletegenre.Location = new System.Drawing.Point(20, 58);
            this.btnDeletegenre.Name = "btnDeletegenre";
            this.btnDeletegenre.Size = new System.Drawing.Size(76, 31);
            this.btnDeletegenre.TabIndex = 7;
            this.btnDeletegenre.Text = "Delete";
            this.btnDeletegenre.UseVisualStyleBackColor = true;
            // 
            // btnAddgenre
            // 
            this.btnAddgenre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddgenre.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddgenre.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnAddgenre.Location = new System.Drawing.Point(20, 19);
            this.btnAddgenre.Name = "btnAddgenre";
            this.btnAddgenre.Size = new System.Drawing.Size(76, 31);
            this.btnAddgenre.TabIndex = 6;
            this.btnAddgenre.Text = "Add";
            this.btnAddgenre.UseVisualStyleBackColor = true;
            // 
            // btnUpdategenre
            // 
            this.btnUpdategenre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdategenre.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUpdategenre.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnUpdategenre.Location = new System.Drawing.Point(20, 96);
            this.btnUpdategenre.Name = "btnUpdategenre";
            this.btnUpdategenre.Size = new System.Drawing.Size(76, 31);
            this.btnUpdategenre.TabIndex = 8;
            this.btnUpdategenre.Text = "Update";
            this.btnUpdategenre.UseVisualStyleBackColor = true;
            // 
            // txtManuCode
            // 
            this.txtManuCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtManuCode.Location = new System.Drawing.Point(149, 39);
            this.txtManuCode.Name = "txtManuCode";
            this.txtManuCode.Size = new System.Drawing.Size(146, 22);
            this.txtManuCode.TabIndex = 11;
            // 
            // txtManuName
            // 
            this.txtManuName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtManuName.Location = new System.Drawing.Point(149, 77);
            this.txtManuName.Name = "txtManuName";
            this.txtManuName.Size = new System.Drawing.Size(146, 22);
            this.txtManuName.TabIndex = 10;
            // 
            // gbGenreInfo
            // 
            this.gbGenreInfo.Controls.Add(this.txtManuCode);
            this.gbGenreInfo.Controls.Add(this.txtManuName);
            this.gbGenreInfo.Controls.Add(this.lbGenreName);
            this.gbGenreInfo.Controls.Add(this.lbGenreID);
            this.gbGenreInfo.Location = new System.Drawing.Point(125, 89);
            this.gbGenreInfo.Name = "gbGenreInfo";
            this.gbGenreInfo.Size = new System.Drawing.Size(308, 141);
            this.gbGenreInfo.TabIndex = 12;
            this.gbGenreInfo.TabStop = false;
            this.gbGenreInfo.Text = "Genre Information";
            // 
            // tabGenre
            // 
            this.tabGenre.BackColor = System.Drawing.SystemColors.Control;
            this.tabGenre.Controls.Add(this.gbFunctions);
            this.tabGenre.Controls.Add(this.gbGenreInfo);
            this.tabGenre.Controls.Add(this.lbManagegenre);
            this.tabGenre.Controls.Add(this.gbgenre);
            this.tabGenre.Location = new System.Drawing.Point(4, 25);
            this.tabGenre.Name = "tabGenre";
            this.tabGenre.Padding = new System.Windows.Forms.Padding(3);
            this.tabGenre.Size = new System.Drawing.Size(787, 586);
            this.tabGenre.TabIndex = 1;
            this.tabGenre.Text = "Genre";
            // 
            // lbManagegenre
            // 
            this.lbManagegenre.AutoSize = true;
            this.lbManagegenre.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbManagegenre.ForeColor = System.Drawing.Color.Blue;
            this.lbManagegenre.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbManagegenre.Location = new System.Drawing.Point(310, 23);
            this.lbManagegenre.Name = "lbManagegenre";
            this.lbManagegenre.Size = new System.Drawing.Size(111, 31);
            this.lbManagegenre.TabIndex = 3;
            this.lbManagegenre.Text = "GENRE";
            // 
            // gbgenre
            // 
            this.gbgenre.Controls.Add(this.dgvgenre);
            this.gbgenre.Location = new System.Drawing.Point(125, 236);
            this.gbgenre.Name = "gbgenre";
            this.gbgenre.Size = new System.Drawing.Size(485, 227);
            this.gbgenre.TabIndex = 2;
            this.gbgenre.TabStop = false;
            this.gbgenre.Text = "List of genres";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(327, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 31);
            this.label4.TabIndex = 13;
            this.label4.Text = "MOVIE";
            // 
            // gbMovie_Genres
            // 
            this.gbMovie_Genres.Controls.Add(this.checkedListBox1);
            this.gbMovie_Genres.Controls.Add(this.txtMovie);
            this.gbMovie_Genres.Controls.Add(this.btnUpdateCarSpecs);
            this.gbMovie_Genres.Controls.Add(this.label5);
            this.gbMovie_Genres.Controls.Add(this.label2);
            this.gbMovie_Genres.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbMovie_Genres.Location = new System.Drawing.Point(95, 72);
            this.gbMovie_Genres.Name = "gbMovie_Genres";
            this.gbMovie_Genres.Size = new System.Drawing.Size(491, 181);
            this.gbMovie_Genres.TabIndex = 18;
            this.gbMovie_Genres.TabStop = false;
            this.gbMovie_Genres.Text = "Movie - Genres";
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.CheckOnClick = true;
            this.checkedListBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Location = new System.Drawing.Point(123, 77);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(270, 89);
            this.checkedListBox1.TabIndex = 30;
            // 
            // txtMovie
            // 
            this.txtMovie.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMovie.Location = new System.Drawing.Point(123, 38);
            this.txtMovie.Name = "txtMovie";
            this.txtMovie.Size = new System.Drawing.Size(270, 22);
            this.txtMovie.TabIndex = 29;
            // 
            // btnUpdateCarSpecs
            // 
            this.btnUpdateCarSpecs.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateCarSpecs.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUpdateCarSpecs.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnUpdateCarSpecs.Location = new System.Drawing.Point(409, 144);
            this.btnUpdateCarSpecs.Name = "btnUpdateCarSpecs";
            this.btnUpdateCarSpecs.Size = new System.Drawing.Size(63, 27);
            this.btnUpdateCarSpecs.TabIndex = 8;
            this.btnUpdateCarSpecs.Text = "Update";
            this.btnUpdateCarSpecs.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(45, 77);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 16);
            this.label5.TabIndex = 18;
            this.label5.Text = "Genres:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(45, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 16);
            this.label2.TabIndex = 16;
            this.label2.Text = "Movie: ";
            // 
            // gbListMovie_Genres
            // 
            this.gbListMovie_Genres.Controls.Add(this.dgvMovie_Genres);
            this.gbListMovie_Genres.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gbListMovie_Genres.Location = new System.Drawing.Point(95, 303);
            this.gbListMovie_Genres.Name = "gbListMovie_Genres";
            this.gbListMovie_Genres.Size = new System.Drawing.Size(491, 191);
            this.gbListMovie_Genres.TabIndex = 19;
            this.gbListMovie_Genres.TabStop = false;
            this.gbListMovie_Genres.Text = "List";
            // 
            // dgvMovie_Genres
            // 
            this.dgvMovie_Genres.AllowUserToAddRows = false;
            this.dgvMovie_Genres.AllowUserToDeleteRows = false;
            this.dgvMovie_Genres.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvMovie_Genres.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvMovie_Genres.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMovie_Genres.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMGMovieName,
            this.colMGGenres,
            this.colMGMovieID});
            this.dgvMovie_Genres.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgvMovie_Genres.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvMovie_Genres.Location = new System.Drawing.Point(3, 18);
            this.dgvMovie_Genres.Name = "dgvMovie_Genres";
            this.dgvMovie_Genres.ReadOnly = true;
            this.dgvMovie_Genres.Size = new System.Drawing.Size(485, 170);
            this.dgvMovie_Genres.TabIndex = 1;
            this.dgvMovie_Genres.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMovie_Genres_CellClick);
            // 
            // colMGMovieName
            // 
            this.colMGMovieName.DataPropertyName = "NAME";
            this.colMGMovieName.HeaderText = "Movie Name";
            this.colMGMovieName.Name = "colMGMovieName";
            this.colMGMovieName.ReadOnly = true;
            // 
            // colMGGenres
            // 
            this.colMGGenres.DataPropertyName = "Genres";
            this.colMGGenres.HeaderText = "Genre(s)";
            this.colMGGenres.Name = "colMGGenres";
            this.colMGGenres.ReadOnly = true;
            this.colMGGenres.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colMGMovieID
            // 
            this.colMGMovieID.DataPropertyName = "MOVIEID";
            this.colMGMovieID.HeaderText = "MovieID";
            this.colMGMovieID.Name = "colMGMovieID";
            this.colMGMovieID.ReadOnly = true;
            this.colMGMovieID.Visible = false;
            // 
            // tabMovie_Genres
            // 
            this.tabMovie_Genres.BackColor = System.Drawing.SystemColors.Control;
            this.tabMovie_Genres.Controls.Add(this.comboBox1);
            this.tabMovie_Genres.Controls.Add(this.textBox1);
            this.tabMovie_Genres.Controls.Add(this.gbListMovie_Genres);
            this.tabMovie_Genres.Controls.Add(this.button1);
            this.tabMovie_Genres.Controls.Add(this.gbMovie_Genres);
            this.tabMovie_Genres.Controls.Add(this.label3);
            this.tabMovie_Genres.Location = new System.Drawing.Point(4, 25);
            this.tabMovie_Genres.Name = "tabMovie_Genres";
            this.tabMovie_Genres.Padding = new System.Windows.Forms.Padding(3);
            this.tabMovie_Genres.Size = new System.Drawing.Size(787, 586);
            this.tabMovie_Genres.TabIndex = 3;
            this.tabMovie_Genres.Text = "Movie_Genres";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(372, 277);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(92, 24);
            this.comboBox1.TabIndex = 23;
            // 
            // textBox1
            // 
            this.textBox1.AccessibleDescription = "asdasda";
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(149, 276);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(217, 22);
            this.textBox1.TabIndex = 22;
            this.textBox1.Text = "Enter Movie Name or Director";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(483, 276);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(72, 24);
            this.button1.TabIndex = 21;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(188, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(355, 31);
            this.label3.TabIndex = 15;
            this.label3.Text = "MANAGE MOVIE_GENRES";
            // 
            // tabMovie
            // 
            this.tabMovie.BackColor = System.Drawing.SystemColors.Control;
            this.tabMovie.Controls.Add(this.cbSearchGenre);
            this.tabMovie.Controls.Add(this.txtKeyword);
            this.tabMovie.Controls.Add(this.groupBoxResult);
            this.tabMovie.Controls.Add(this.gbCarInfomation);
            this.tabMovie.Controls.Add(this.btnSearch);
            this.tabMovie.Controls.Add(this.label4);
            this.tabMovie.Location = new System.Drawing.Point(4, 25);
            this.tabMovie.Name = "tabMovie";
            this.tabMovie.Padding = new System.Windows.Forms.Padding(3);
            this.tabMovie.Size = new System.Drawing.Size(787, 586);
            this.tabMovie.TabIndex = 2;
            this.tabMovie.Text = "Movie";
            // 
            // cbSearchGenre
            // 
            this.cbSearchGenre.DataSource = this.gENREBindingSource;
            this.cbSearchGenre.DisplayMember = "GENRENAME";
            this.cbSearchGenre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSearchGenre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbSearchGenre.FormattingEnabled = true;
            this.cbSearchGenre.Location = new System.Drawing.Point(420, 329);
            this.cbSearchGenre.Name = "cbSearchGenre";
            this.cbSearchGenre.Size = new System.Drawing.Size(92, 24);
            this.cbSearchGenre.TabIndex = 20;
            this.cbSearchGenre.ValueMember = "GENREID";
            // 
            // txtKeyword
            // 
            this.txtKeyword.AccessibleDescription = "asdasda";
            this.txtKeyword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKeyword.Location = new System.Drawing.Point(197, 329);
            this.txtKeyword.Name = "txtKeyword";
            this.txtKeyword.Size = new System.Drawing.Size(217, 22);
            this.txtKeyword.TabIndex = 19;
            this.txtKeyword.Text = "Enter Movie Name or Director";
            this.txtKeyword.Enter += new System.EventHandler(this.txtKeyword_Enter);
            this.txtKeyword.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtKeyword_KeyDown);
            this.txtKeyword.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtKeyword_KeyUp);
            // 
            // groupBoxResult
            // 
            this.groupBoxResult.Controls.Add(this.dgvResult);
            this.groupBoxResult.Cursor = System.Windows.Forms.Cursors.Hand;
            this.groupBoxResult.Location = new System.Drawing.Point(45, 357);
            this.groupBoxResult.Name = "groupBoxResult";
            this.groupBoxResult.Size = new System.Drawing.Size(692, 207);
            this.groupBoxResult.TabIndex = 16;
            this.groupBoxResult.TabStop = false;
            this.groupBoxResult.Text = "List of Result";
            // 
            // dgvResult
            // 
            this.dgvResult.AllowUserToAddRows = false;
            this.dgvResult.AllowUserToDeleteRows = false;
            this.dgvResult.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResult.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMovieID,
            this.colMovieName,
            this.colDirector,
            this.colGenre,
            this.colReleaseYear,
            this.colLength,
            this.colIMDB,
            this.colSpotSummary,
            this.colImagePath,
            this.colTrailerPath});
            this.dgvResult.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgvResult.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgvResult.Location = new System.Drawing.Point(3, 18);
            this.dgvResult.Name = "dgvResult";
            this.dgvResult.ReadOnly = true;
            this.dgvResult.Size = new System.Drawing.Size(686, 188);
            this.dgvResult.TabIndex = 2;
            this.dgvResult.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvResult_CellClick);
            // 
            // colMovieID
            // 
            this.colMovieID.DataPropertyName = "MOVIEID";
            this.colMovieID.HeaderText = "MovieID";
            this.colMovieID.Name = "colMovieID";
            this.colMovieID.ReadOnly = true;
            this.colMovieID.Width = 72;
            // 
            // colMovieName
            // 
            this.colMovieName.DataPropertyName = "NAME";
            this.colMovieName.HeaderText = "Movie Name";
            this.colMovieName.Name = "colMovieName";
            this.colMovieName.ReadOnly = true;
            this.colMovieName.Width = 92;
            // 
            // colDirector
            // 
            this.colDirector.DataPropertyName = "DIRECTOR";
            this.colDirector.HeaderText = "Director";
            this.colDirector.Name = "colDirector";
            this.colDirector.ReadOnly = true;
            this.colDirector.Width = 69;
            // 
            // colGenre
            // 
            this.colGenre.DataPropertyName = "Genres";
            this.colGenre.HeaderText = "Genre(s)";
            this.colGenre.Name = "colGenre";
            this.colGenre.ReadOnly = true;
            this.colGenre.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colGenre.Width = 72;
            // 
            // colReleaseYear
            // 
            this.colReleaseYear.DataPropertyName = "ReleaseYear";
            this.colReleaseYear.HeaderText = "ReleaseYear";
            this.colReleaseYear.Name = "colReleaseYear";
            this.colReleaseYear.ReadOnly = true;
            this.colReleaseYear.Width = 93;
            // 
            // colLength
            // 
            this.colLength.DataPropertyName = "Length";
            this.colLength.HeaderText = "Length";
            this.colLength.Name = "colLength";
            this.colLength.ReadOnly = true;
            this.colLength.Width = 65;
            // 
            // colIMDB
            // 
            this.colIMDB.DataPropertyName = "IMDB";
            this.colIMDB.HeaderText = "IMDB";
            this.colIMDB.Name = "colIMDB";
            this.colIMDB.ReadOnly = true;
            this.colIMDB.Width = 59;
            // 
            // colSpotSummary
            // 
            this.colSpotSummary.DataPropertyName = "SPOTSUMMARY";
            this.colSpotSummary.HeaderText = "Spot Summary";
            this.colSpotSummary.Name = "colSpotSummary";
            this.colSpotSummary.ReadOnly = true;
            // 
            // colImagePath
            // 
            this.colImagePath.DataPropertyName = "ImagePath";
            this.colImagePath.HeaderText = "ImagePath";
            this.colImagePath.Name = "colImagePath";
            this.colImagePath.ReadOnly = true;
            this.colImagePath.Width = 83;
            // 
            // colTrailerPath
            // 
            this.colTrailerPath.DataPropertyName = "TrailerPath";
            this.colTrailerPath.HeaderText = "TrailerPath";
            this.colTrailerPath.Name = "colTrailerPath";
            this.colTrailerPath.ReadOnly = true;
            this.colTrailerPath.Width = 83;
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabMovie);
            this.tabControl.Controls.Add(this.tabMovie_Genres);
            this.tabControl.Controls.Add(this.tabGenre);
            this.tabControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl.Location = new System.Drawing.Point(35, 26);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(795, 615);
            this.tabControl.TabIndex = 3;
            // 
            // gENRETableAdapter
            // 
            this.gENRETableAdapter.ClearBeforeFill = true;
            // 
            // frmManage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 658);
            this.Controls.Add(this.tabControl);
            this.Name = "frmManage";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.gbCarInfomation.ResumeLayout(false);
            this.gbCarInfomation.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvgenre)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gENREBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet)).EndInit();
            this.gbFunctions.ResumeLayout(false);
            this.gbGenreInfo.ResumeLayout(false);
            this.gbGenreInfo.PerformLayout();
            this.tabGenre.ResumeLayout(false);
            this.tabGenre.PerformLayout();
            this.gbgenre.ResumeLayout(false);
            this.gbMovie_Genres.ResumeLayout(false);
            this.gbMovie_Genres.PerformLayout();
            this.gbListMovie_Genres.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMovie_Genres)).EndInit();
            this.tabMovie_Genres.ResumeLayout(false);
            this.tabMovie_Genres.PerformLayout();
            this.tabMovie.ResumeLayout(false);
            this.tabMovie.PerformLayout();
            this.groupBoxResult.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).EndInit();
            this.tabControl.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox txtImage;
        private System.Windows.Forms.GroupBox gbCarInfomation;
        private System.Windows.Forms.Button btnChooseImage;
        private System.Windows.Forms.TextBox txtMovieName;
        private System.Windows.Forms.Label lbMovieName;
        private System.Windows.Forms.Label lbIMDB;
        private System.Windows.Forms.TextBox txtLength;
        private System.Windows.Forms.Label lbLength;
        private System.Windows.Forms.TextBox txtReleaseYear;
        private System.Windows.Forms.TextBox txtMovieID;
        private System.Windows.Forms.Label lbDirector;
        private System.Windows.Forms.Label lbReleaseYear;
        private System.Windows.Forms.Label lbImage;
        private System.Windows.Forms.Label lbMovieID;
        private System.Windows.Forms.DataGridView dgvgenre;
        private System.Windows.Forms.Label lbGenreName;
        private System.Windows.Forms.Label lbGenreID;
        private System.Windows.Forms.GroupBox gbFunctions;
        private System.Windows.Forms.Button btnDeletegenre;
        private System.Windows.Forms.Button btnAddgenre;
        private System.Windows.Forms.Button btnUpdategenre;
        private System.Windows.Forms.TextBox txtManuCode;
        private System.Windows.Forms.TextBox txtManuName;
        private System.Windows.Forms.GroupBox gbGenreInfo;
        private System.Windows.Forms.TabPage tabGenre;
        private System.Windows.Forms.Label lbManagegenre;
        private System.Windows.Forms.GroupBox gbgenre;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox gbMovie_Genres;
        private System.Windows.Forms.GroupBox gbListMovie_Genres;
        private System.Windows.Forms.TabPage tabMovie_Genres;
        private System.Windows.Forms.Button btnUpdateCarSpecs;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabMovie;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.GroupBox groupBoxResult;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn;
        private System.Windows.Forms.Button btnDeleteMovie;
        private System.Windows.Forms.Button btnAddMovie;
        private System.Windows.Forms.Button btnUpdateMovie;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtTrailer;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private dbMovieForRentDataSet dbMovieForRentDataSet;
        private System.Windows.Forms.BindingSource dbMovieForRentDataSetBindingSource;
        private System.Windows.Forms.BindingSource gENREBindingSource;
        private dbMovieForRentDataSetTableAdapters.GENRETableAdapter gENRETableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn gENREIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gENRENAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dgvResult;
        private System.Windows.Forms.TextBox txtKeyword;
        private System.Windows.Forms.ComboBox cbSearchGenre;
        private System.Windows.Forms.TextBox txtDirector;
        private System.Windows.Forms.TextBox txtIMDB;
        private System.Windows.Forms.Label Summary;
        private System.Windows.Forms.RichTextBox rtxtSpotSummary;
        private System.Windows.Forms.TextBox txtMovie;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dgvMovie_Genres;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMGMovieName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMGGenres;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMGMovieID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMovieID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMovieName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDirector;
        private System.Windows.Forms.DataGridViewTextBoxColumn colGenre;
        private System.Windows.Forms.DataGridViewTextBoxColumn colReleaseYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLength;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIMDB;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSpotSummary;
        private System.Windows.Forms.DataGridViewTextBoxColumn colImagePath;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTrailerPath;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
    }
}