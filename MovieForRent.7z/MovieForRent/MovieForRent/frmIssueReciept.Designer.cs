﻿namespace MovieForRent
{
    partial class frmIssueReciept
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmIssueReciept));
            this.gbListofStockMovement = new System.Windows.Forms.GroupBox();
            this.dgvStockManagement = new System.Windows.Forms.DataGridView();
            this.gbInformation = new System.Windows.Forms.GroupBox();
            this.lbReceiptPrice = new System.Windows.Forms.Label();
            this.txtReceiptPrice = new System.Windows.Forms.TextBox();
            this.lbNote = new System.Windows.Forms.Label();
            this.txtNote = new System.Windows.Forms.TextBox();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.lblDate = new System.Windows.Forms.Label();
            this.lbReceipt = new System.Windows.Forms.Label();
            this.txtReceiptQuantity = new System.Windows.Forms.TextBox();
            this.lbIssueQuantity = new System.Windows.Forms.Label();
            this.txtIssueQuantity = new System.Windows.Forms.TextBox();
            this.lbMovieID = new System.Windows.Forms.Label();
            this.txtMovieID = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.dgvInventory = new System.Windows.Forms.DataGridView();
            this.dbMovieForRentDataSet2 = new MovieForRent.dbMovieForRentDataSet2();
            this.dbMovieForRentDataSet2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iNVENTORYBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iNVENTORYTableAdapter = new MovieForRent.dbMovieForRentDataSet2TableAdapters.INVENTORYTableAdapter();
            this.gbInventory = new System.Windows.Forms.GroupBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.gbListofStockMovement.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStockManagement)).BeginInit();
            this.gbInformation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iNVENTORYBindingSource)).BeginInit();
            this.gbInventory.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbListofStockMovement
            // 
            this.gbListofStockMovement.Controls.Add(this.dgvStockManagement);
            this.gbListofStockMovement.Location = new System.Drawing.Point(44, 427);
            this.gbListofStockMovement.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbListofStockMovement.Name = "gbListofStockMovement";
            this.gbListofStockMovement.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbListofStockMovement.Size = new System.Drawing.Size(984, 251);
            this.gbListofStockMovement.TabIndex = 33;
            this.gbListofStockMovement.TabStop = false;
            this.gbListofStockMovement.Text = "List of Stock Movements";
            // 
            // dgvStockManagement
            // 
            this.dgvStockManagement.AllowUserToAddRows = false;
            this.dgvStockManagement.AllowUserToDeleteRows = false;
            this.dgvStockManagement.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvStockManagement.BackgroundColor = System.Drawing.Color.White;
            this.dgvStockManagement.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStockManagement.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvStockManagement.Location = new System.Drawing.Point(4, 19);
            this.dgvStockManagement.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvStockManagement.Name = "dgvStockManagement";
            this.dgvStockManagement.ReadOnly = true;
            this.dgvStockManagement.RowTemplate.Height = 24;
            this.dgvStockManagement.Size = new System.Drawing.Size(976, 228);
            this.dgvStockManagement.TabIndex = 16;
            // 
            // gbInformation
            // 
            this.gbInformation.Controls.Add(this.lbReceiptPrice);
            this.gbInformation.Controls.Add(this.txtReceiptPrice);
            this.gbInformation.Controls.Add(this.lbNote);
            this.gbInformation.Controls.Add(this.txtNote);
            this.gbInformation.Controls.Add(this.dtpDate);
            this.gbInformation.Controls.Add(this.lblDate);
            this.gbInformation.Controls.Add(this.lbReceipt);
            this.gbInformation.Controls.Add(this.txtReceiptQuantity);
            this.gbInformation.Controls.Add(this.lbIssueQuantity);
            this.gbInformation.Controls.Add(this.txtIssueQuantity);
            this.gbInformation.Controls.Add(this.lbMovieID);
            this.gbInformation.Controls.Add(this.txtMovieID);
            this.gbInformation.Controls.Add(this.btnAdd);
            this.gbInformation.Location = new System.Drawing.Point(535, 41);
            this.gbInformation.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbInformation.Name = "gbInformation";
            this.gbInformation.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbInformation.Size = new System.Drawing.Size(493, 356);
            this.gbInformation.TabIndex = 32;
            this.gbInformation.TabStop = false;
            this.gbInformation.Text = "Information";
            // 
            // lbReceiptPrice
            // 
            this.lbReceiptPrice.AutoSize = true;
            this.lbReceiptPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbReceiptPrice.Location = new System.Drawing.Point(34, 200);
            this.lbReceiptPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbReceiptPrice.Name = "lbReceiptPrice";
            this.lbReceiptPrice.Size = new System.Drawing.Size(115, 20);
            this.lbReceiptPrice.TabIndex = 37;
            this.lbReceiptPrice.Text = "Receipt Price:";
            // 
            // txtReceiptPrice
            // 
            this.txtReceiptPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReceiptPrice.Location = new System.Drawing.Point(210, 197);
            this.txtReceiptPrice.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtReceiptPrice.Name = "txtReceiptPrice";
            this.txtReceiptPrice.Size = new System.Drawing.Size(247, 26);
            this.txtReceiptPrice.TabIndex = 36;
            this.txtReceiptPrice.Text = "0";
            this.txtReceiptPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReceiptPrice_KeyPress);
            // 
            // lbNote
            // 
            this.lbNote.AutoSize = true;
            this.lbNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNote.Location = new System.Drawing.Point(35, 243);
            this.lbNote.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbNote.Name = "lbNote";
            this.lbNote.Size = new System.Drawing.Size(49, 20);
            this.lbNote.TabIndex = 35;
            this.lbNote.Text = "Note:";
            // 
            // txtNote
            // 
            this.txtNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNote.Location = new System.Drawing.Point(210, 240);
            this.txtNote.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNote.Name = "txtNote";
            this.txtNote.Size = new System.Drawing.Size(247, 26);
            this.txtNote.TabIndex = 34;
            // 
            // dtpDate
            // 
            this.dtpDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDate.Location = new System.Drawing.Point(210, 157);
            this.dtpDate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(247, 26);
            this.dtpDate.TabIndex = 33;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(34, 157);
            this.lblDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(50, 20);
            this.lblDate.TabIndex = 32;
            this.lblDate.Text = "Date:";
            // 
            // lbReceipt
            // 
            this.lbReceipt.AutoSize = true;
            this.lbReceipt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbReceipt.Location = new System.Drawing.Point(34, 76);
            this.lbReceipt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbReceipt.Name = "lbReceipt";
            this.lbReceipt.Size = new System.Drawing.Size(133, 20);
            this.lbReceipt.TabIndex = 31;
            this.lbReceipt.Text = "Receipt Quantity";
            // 
            // txtReceiptQuantity
            // 
            this.txtReceiptQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReceiptQuantity.Location = new System.Drawing.Point(210, 73);
            this.txtReceiptQuantity.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtReceiptQuantity.Name = "txtReceiptQuantity";
            this.txtReceiptQuantity.Size = new System.Drawing.Size(247, 26);
            this.txtReceiptQuantity.TabIndex = 30;
            this.txtReceiptQuantity.Text = "0";
            this.txtReceiptQuantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.QuantityAndPrice_keyPress);
            // 
            // lbIssueQuantity
            // 
            this.lbIssueQuantity.AutoSize = true;
            this.lbIssueQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbIssueQuantity.Location = new System.Drawing.Point(34, 120);
            this.lbIssueQuantity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbIssueQuantity.Name = "lbIssueQuantity";
            this.lbIssueQuantity.Size = new System.Drawing.Size(121, 20);
            this.lbIssueQuantity.TabIndex = 29;
            this.lbIssueQuantity.Text = "Issue Quantity:";
            // 
            // txtIssueQuantity
            // 
            this.txtIssueQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIssueQuantity.Location = new System.Drawing.Point(210, 117);
            this.txtIssueQuantity.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtIssueQuantity.Name = "txtIssueQuantity";
            this.txtIssueQuantity.Size = new System.Drawing.Size(247, 26);
            this.txtIssueQuantity.TabIndex = 28;
            this.txtIssueQuantity.Text = "0";
            this.txtIssueQuantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.QuantityAndPrice_keyPress);
            // 
            // lbMovieID
            // 
            this.lbMovieID.AutoSize = true;
            this.lbMovieID.BackColor = System.Drawing.Color.White;
            this.lbMovieID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMovieID.Location = new System.Drawing.Point(34, 32);
            this.lbMovieID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbMovieID.Name = "lbMovieID";
            this.lbMovieID.Size = new System.Drawing.Size(75, 20);
            this.lbMovieID.TabIndex = 27;
            this.lbMovieID.Text = "MovieID:";
            // 
            // txtMovieID
            // 
            this.txtMovieID.BackColor = System.Drawing.Color.White;
            this.txtMovieID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMovieID.Location = new System.Drawing.Point(213, 28);
            this.txtMovieID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMovieID.Name = "txtMovieID";
            this.txtMovieID.ReadOnly = true;
            this.txtMovieID.Size = new System.Drawing.Size(247, 26);
            this.txtMovieID.TabIndex = 20;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdd.Location = new System.Drawing.Point(210, 287);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(95, 35);
            this.btnAdd.TabIndex = 26;
            this.btnAdd.Text = "Add";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // dgvInventory
            // 
            this.dgvInventory.AllowUserToAddRows = false;
            this.dgvInventory.AllowUserToDeleteRows = false;
            this.dgvInventory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvInventory.BackgroundColor = System.Drawing.Color.White;
            this.dgvInventory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInventory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvInventory.Location = new System.Drawing.Point(4, 19);
            this.dgvInventory.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvInventory.Name = "dgvInventory";
            this.dgvInventory.ReadOnly = true;
            this.dgvInventory.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvInventory.Size = new System.Drawing.Size(388, 333);
            this.dgvInventory.TabIndex = 34;
            this.dgvInventory.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellClick);
            // 
            // dbMovieForRentDataSet2
            // 
            this.dbMovieForRentDataSet2.DataSetName = "dbMovieForRentDataSet2";
            this.dbMovieForRentDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dbMovieForRentDataSet2BindingSource
            // 
            this.dbMovieForRentDataSet2BindingSource.DataSource = this.dbMovieForRentDataSet2;
            this.dbMovieForRentDataSet2BindingSource.Position = 0;
            // 
            // iNVENTORYBindingSource
            // 
            this.iNVENTORYBindingSource.DataMember = "INVENTORY";
            this.iNVENTORYBindingSource.DataSource = this.dbMovieForRentDataSet2BindingSource;
            // 
            // iNVENTORYTableAdapter
            // 
            this.iNVENTORYTableAdapter.ClearBeforeFill = true;
            // 
            // gbInventory
            // 
            this.gbInventory.Controls.Add(this.dgvInventory);
            this.gbInventory.Location = new System.Drawing.Point(44, 41);
            this.gbInventory.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbInventory.Name = "gbInventory";
            this.gbInventory.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbInventory.Size = new System.Drawing.Size(396, 356);
            this.gbInventory.TabIndex = 35;
            this.gbInventory.TabStop = false;
            this.gbInventory.Text = "Inventory";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // frmIssueReciept
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1074, 723);
            this.Controls.Add(this.gbInventory);
            this.Controls.Add(this.gbListofStockMovement);
            this.Controls.Add(this.gbInformation);
            this.ForeColor = System.Drawing.Color.MidnightBlue;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmIssueReciept";
            this.Text = "Issue/Reciept";
            this.Load += new System.EventHandler(this.frmIssueReciept_Load);
            this.gbListofStockMovement.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStockManagement)).EndInit();
            this.gbInformation.ResumeLayout(false);
            this.gbInformation.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iNVENTORYBindingSource)).EndInit();
            this.gbInventory.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbListofStockMovement;
        private System.Windows.Forms.DataGridView dgvStockManagement;
        private System.Windows.Forms.GroupBox gbInformation;
        private System.Windows.Forms.Label lbReceipt;
        private System.Windows.Forms.TextBox txtReceiptQuantity;
        private System.Windows.Forms.Label lbIssueQuantity;
        private System.Windows.Forms.TextBox txtIssueQuantity;
        private System.Windows.Forms.Label lbMovieID;
        private System.Windows.Forms.TextBox txtMovieID;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.TextBox txtNote;
        private System.Windows.Forms.DataGridView dgvInventory;
        private System.Windows.Forms.BindingSource dbMovieForRentDataSet2BindingSource;
        private dbMovieForRentDataSet2 dbMovieForRentDataSet2;
        private System.Windows.Forms.BindingSource iNVENTORYBindingSource;
        private dbMovieForRentDataSet2TableAdapters.INVENTORYTableAdapter iNVENTORYTableAdapter;
        private System.Windows.Forms.TextBox txtReceiptPrice;
        private System.Windows.Forms.Label lbReceiptPrice;
        private System.Windows.Forms.Label lbNote;
        private System.Windows.Forms.GroupBox gbInventory;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
    }
}