﻿namespace MovieForRent
{
    partial class frmTransactionDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTransactionDetail));
            this.dtpDueDate = new System.Windows.Forms.DateTimePicker();
            this.lblReceived = new System.Windows.Forms.Label();
            this.dtpReceivedDate = new System.Windows.Forms.DateTimePicker();
            this.lblReturned = new System.Windows.Forms.Label();
            this.lblDueDate = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.btnTransUpdate = new System.Windows.Forms.Button();
            this.cbIsReturned = new System.Windows.Forms.ComboBox();
            this.cbIsReceived = new System.Windows.Forms.ComboBox();
            this.txtTransactionID = new System.Windows.Forms.TextBox();
            this.lblReceivedDate = new System.Windows.Forms.Label();
            this.iNVENTORYBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dbMovieForRentDataSet2 = new MovieForRent.dbMovieForRentDataSet2();
            this.gbRent = new System.Windows.Forms.GroupBox();
            this.lblTransactionID = new System.Windows.Forms.Label();
            this.dgvTransaction = new System.Windows.Forms.DataGridView();
            this.TRANSACTIONID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CUSTOMERID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MOVIEID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RECEIVEDDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DUEDATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.STATUS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tRANSACTIONSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dbMovieForRentDataSet1 = new MovieForRent.dbMovieForRentDataSet1();
            this.dbMovieForRentDataSet = new MovieForRent.dbMovieForRentDataSet();
            this.dbMovieForRentDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dbMovieForRentDataSetBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tRANSACTIONSTableAdapter = new MovieForRent.dbMovieForRentDataSet1TableAdapters.TRANSACTIONSTableAdapter();
            this.iNVENTORYTableAdapter = new MovieForRent.dbMovieForRentDataSet2TableAdapters.INVENTORYTableAdapter();
            this.gbTransactionDetail = new System.Windows.Forms.GroupBox();
            this.gbBuy = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbReceived_buy = new System.Windows.Forms.ComboBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.iNVENTORYBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet2)).BeginInit();
            this.gbRent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTransaction)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tRANSACTIONSBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSetBindingSource1)).BeginInit();
            this.gbTransactionDetail.SuspendLayout();
            this.gbBuy.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtpDueDate
            // 
            this.dtpDueDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDueDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDueDate.Location = new System.Drawing.Point(208, 145);
            this.dtpDueDate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtpDueDate.Name = "dtpDueDate";
            this.dtpDueDate.Size = new System.Drawing.Size(247, 26);
            this.dtpDueDate.TabIndex = 24;
            // 
            // lblReceived
            // 
            this.lblReceived.AutoSize = true;
            this.lblReceived.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReceived.Location = new System.Drawing.Point(32, 105);
            this.lblReceived.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblReceived.Name = "lblReceived";
            this.lblReceived.Size = new System.Drawing.Size(87, 20);
            this.lblReceived.TabIndex = 18;
            this.lblReceived.Text = "Received?";
            // 
            // dtpReceivedDate
            // 
            this.dtpReceivedDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpReceivedDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpReceivedDate.Location = new System.Drawing.Point(208, 57);
            this.dtpReceivedDate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtpReceivedDate.Name = "dtpReceivedDate";
            this.dtpReceivedDate.Size = new System.Drawing.Size(247, 26);
            this.dtpReceivedDate.TabIndex = 22;
            // 
            // lblReturned
            // 
            this.lblReturned.AutoSize = true;
            this.lblReturned.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturned.Location = new System.Drawing.Point(32, 198);
            this.lblReturned.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblReturned.Name = "lblReturned";
            this.lblReturned.Size = new System.Drawing.Size(86, 20);
            this.lblReturned.TabIndex = 21;
            this.lblReturned.Text = "Returned?";
            // 
            // lblDueDate
            // 
            this.lblDueDate.AutoSize = true;
            this.lblDueDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDueDate.Location = new System.Drawing.Point(32, 145);
            this.lblDueDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDueDate.Name = "lblDueDate";
            this.lblDueDate.Size = new System.Drawing.Size(86, 20);
            this.lblDueDate.TabIndex = 19;
            this.lblDueDate.Text = "Due Date:";
            // 
            // btnTransUpdate
            // 
            this.btnTransUpdate.BackColor = System.Drawing.Color.White;
            this.btnTransUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTransUpdate.Image = ((System.Drawing.Image)(resources.GetObject("btnTransUpdate.Image")));
            this.btnTransUpdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTransUpdate.Location = new System.Drawing.Point(176, 246);
            this.btnTransUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTransUpdate.Name = "btnTransUpdate";
            this.btnTransUpdate.Size = new System.Drawing.Size(95, 35);
            this.btnTransUpdate.TabIndex = 26;
            this.btnTransUpdate.Text = "Update";
            this.btnTransUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTransUpdate.UseVisualStyleBackColor = false;
            this.btnTransUpdate.Click += new System.EventHandler(this.btnTransUpdate_Click);
            // 
            // cbIsReturned
            // 
            this.cbIsReturned.BackColor = System.Drawing.Color.White;
            this.cbIsReturned.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbIsReturned.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbIsReturned.FormattingEnabled = true;
            this.cbIsReturned.Items.AddRange(new object[] {
            "NO",
            "YES"});
            this.cbIsReturned.Location = new System.Drawing.Point(208, 188);
            this.cbIsReturned.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbIsReturned.Name = "cbIsReturned";
            this.cbIsReturned.Size = new System.Drawing.Size(247, 28);
            this.cbIsReturned.TabIndex = 25;
            this.cbIsReturned.SelectedIndexChanged += new System.EventHandler(this.cbIsReturned_SelectedIndexChanged);
            // 
            // cbIsReceived
            // 
            this.cbIsReceived.BackColor = System.Drawing.Color.White;
            this.cbIsReceived.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbIsReceived.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbIsReceived.FormattingEnabled = true;
            this.cbIsReceived.Items.AddRange(new object[] {
            "NO",
            "YES"});
            this.cbIsReceived.Location = new System.Drawing.Point(208, 101);
            this.cbIsReceived.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbIsReceived.Name = "cbIsReceived";
            this.cbIsReceived.Size = new System.Drawing.Size(247, 28);
            this.cbIsReceived.TabIndex = 23;
            this.cbIsReceived.SelectedIndexChanged += new System.EventHandler(this.cbIsReceived_SelectedIndexChanged);
            // 
            // txtTransactionID
            // 
            this.txtTransactionID.BackColor = System.Drawing.Color.White;
            this.txtTransactionID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTransactionID.Location = new System.Drawing.Point(482, 350);
            this.txtTransactionID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTransactionID.Name = "txtTransactionID";
            this.txtTransactionID.ReadOnly = true;
            this.txtTransactionID.Size = new System.Drawing.Size(303, 26);
            this.txtTransactionID.TabIndex = 20;
            // 
            // lblReceivedDate
            // 
            this.lblReceivedDate.AutoSize = true;
            this.lblReceivedDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReceivedDate.Location = new System.Drawing.Point(32, 63);
            this.lblReceivedDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblReceivedDate.Name = "lblReceivedDate";
            this.lblReceivedDate.Size = new System.Drawing.Size(124, 20);
            this.lblReceivedDate.TabIndex = 17;
            this.lblReceivedDate.Text = "Received Date:";
            // 
            // iNVENTORYBindingSource
            // 
            this.iNVENTORYBindingSource.DataMember = "INVENTORY";
            this.iNVENTORYBindingSource.DataSource = this.dbMovieForRentDataSet2;
            // 
            // dbMovieForRentDataSet2
            // 
            this.dbMovieForRentDataSet2.DataSetName = "dbMovieForRentDataSet2";
            this.dbMovieForRentDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gbRent
            // 
            this.gbRent.Controls.Add(this.dtpDueDate);
            this.gbRent.Controls.Add(this.lblReceivedDate);
            this.gbRent.Controls.Add(this.lblReceived);
            this.gbRent.Controls.Add(this.cbIsReceived);
            this.gbRent.Controls.Add(this.dtpReceivedDate);
            this.gbRent.Controls.Add(this.cbIsReturned);
            this.gbRent.Controls.Add(this.lblReturned);
            this.gbRent.Controls.Add(this.btnTransUpdate);
            this.gbRent.Controls.Add(this.lblDueDate);
            this.gbRent.Location = new System.Drawing.Point(100, 405);
            this.gbRent.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbRent.Name = "gbRent";
            this.gbRent.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbRent.Size = new System.Drawing.Size(497, 310);
            this.gbRent.TabIndex = 27;
            this.gbRent.TabStop = false;
            this.gbRent.Text = "Rent";
            // 
            // lblTransactionID
            // 
            this.lblTransactionID.AutoSize = true;
            this.lblTransactionID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTransactionID.Location = new System.Drawing.Point(304, 353);
            this.lblTransactionID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTransactionID.Name = "lblTransactionID";
            this.lblTransactionID.Size = new System.Drawing.Size(129, 20);
            this.lblTransactionID.TabIndex = 27;
            this.lblTransactionID.Text = "Transaction ID: ";
            // 
            // dgvTransaction
            // 
            this.dgvTransaction.AllowUserToAddRows = false;
            this.dgvTransaction.AllowUserToDeleteRows = false;
            this.dgvTransaction.AutoGenerateColumns = false;
            this.dgvTransaction.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTransaction.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTransaction.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TRANSACTIONID,
            this.CUSTOMERID,
            this.MOVIEID,
            this.RECEIVEDDATE,
            this.DUEDATE,
            this.STATUS});
            this.dgvTransaction.DataSource = this.tRANSACTIONSBindingSource;
            this.dgvTransaction.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTransaction.Location = new System.Drawing.Point(4, 19);
            this.dgvTransaction.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvTransaction.Name = "dgvTransaction";
            this.dgvTransaction.ReadOnly = true;
            this.dgvTransaction.Size = new System.Drawing.Size(1059, 280);
            this.dgvTransaction.TabIndex = 28;
            this.dgvTransaction.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTransaction_CellClick);
            // 
            // TRANSACTIONID
            // 
            this.TRANSACTIONID.DataPropertyName = "TRANSACTIONID";
            this.TRANSACTIONID.HeaderText = "TRANSACTIONID";
            this.TRANSACTIONID.Name = "TRANSACTIONID";
            this.TRANSACTIONID.ReadOnly = true;
            // 
            // CUSTOMERID
            // 
            this.CUSTOMERID.DataPropertyName = "CUSTOMERID";
            this.CUSTOMERID.HeaderText = "CUSTOMERID";
            this.CUSTOMERID.Name = "CUSTOMERID";
            this.CUSTOMERID.ReadOnly = true;
            // 
            // MOVIEID
            // 
            this.MOVIEID.DataPropertyName = "MOVIEID";
            this.MOVIEID.HeaderText = "MOVIEID";
            this.MOVIEID.Name = "MOVIEID";
            this.MOVIEID.ReadOnly = true;
            // 
            // RECEIVEDDATE
            // 
            this.RECEIVEDDATE.DataPropertyName = "RECEIVEDDATE";
            this.RECEIVEDDATE.HeaderText = "RECEIVED DATE";
            this.RECEIVEDDATE.Name = "RECEIVEDDATE";
            this.RECEIVEDDATE.ReadOnly = true;
            // 
            // DUEDATE
            // 
            this.DUEDATE.DataPropertyName = "DUEDATE";
            this.DUEDATE.HeaderText = "DUE DATE";
            this.DUEDATE.Name = "DUEDATE";
            this.DUEDATE.ReadOnly = true;
            // 
            // STATUS
            // 
            this.STATUS.DataPropertyName = "STATUS";
            this.STATUS.HeaderText = "STATUS";
            this.STATUS.Name = "STATUS";
            this.STATUS.ReadOnly = true;
            // 
            // tRANSACTIONSBindingSource
            // 
            this.tRANSACTIONSBindingSource.DataMember = "TRANSACTIONS";
            this.tRANSACTIONSBindingSource.DataSource = this.dbMovieForRentDataSet1;
            // 
            // dbMovieForRentDataSet1
            // 
            this.dbMovieForRentDataSet1.DataSetName = "dbMovieForRentDataSet1";
            this.dbMovieForRentDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dbMovieForRentDataSet
            // 
            this.dbMovieForRentDataSet.DataSetName = "dbMovieForRentDataSet";
            this.dbMovieForRentDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dbMovieForRentDataSetBindingSource
            // 
            this.dbMovieForRentDataSetBindingSource.DataSource = this.dbMovieForRentDataSet;
            this.dbMovieForRentDataSetBindingSource.Position = 0;
            // 
            // dbMovieForRentDataSetBindingSource1
            // 
            this.dbMovieForRentDataSetBindingSource1.DataSource = this.dbMovieForRentDataSet;
            this.dbMovieForRentDataSetBindingSource1.Position = 0;
            // 
            // tRANSACTIONSTableAdapter
            // 
            this.tRANSACTIONSTableAdapter.ClearBeforeFill = true;
            // 
            // iNVENTORYTableAdapter
            // 
            this.iNVENTORYTableAdapter.ClearBeforeFill = true;
            // 
            // gbTransactionDetail
            // 
            this.gbTransactionDetail.Controls.Add(this.dgvTransaction);
            this.gbTransactionDetail.Location = new System.Drawing.Point(100, 32);
            this.gbTransactionDetail.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbTransactionDetail.Name = "gbTransactionDetail";
            this.gbTransactionDetail.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbTransactionDetail.Size = new System.Drawing.Size(1067, 303);
            this.gbTransactionDetail.TabIndex = 30;
            this.gbTransactionDetail.TabStop = false;
            this.gbTransactionDetail.Text = "List of Transaction Details";
            // 
            // gbBuy
            // 
            this.gbBuy.Controls.Add(this.label1);
            this.gbBuy.Controls.Add(this.label2);
            this.gbBuy.Controls.Add(this.cbReceived_buy);
            this.gbBuy.Controls.Add(this.dateTimePicker2);
            this.gbBuy.Controls.Add(this.button1);
            this.gbBuy.Location = new System.Drawing.Point(666, 405);
            this.gbBuy.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbBuy.Name = "gbBuy";
            this.gbBuy.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbBuy.Size = new System.Drawing.Size(497, 310);
            this.gbBuy.TabIndex = 31;
            this.gbBuy.TabStop = false;
            this.gbBuy.Text = "Buy";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 105);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "Received Date:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(32, 145);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 20);
            this.label2.TabIndex = 18;
            this.label2.Text = "Received?";
            // 
            // cbReceived_buy
            // 
            this.cbReceived_buy.BackColor = System.Drawing.Color.White;
            this.cbReceived_buy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbReceived_buy.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbReceived_buy.FormattingEnabled = true;
            this.cbReceived_buy.Items.AddRange(new object[] {
            "NO",
            "YES"});
            this.cbReceived_buy.Location = new System.Drawing.Point(209, 142);
            this.cbReceived_buy.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbReceived_buy.Name = "cbReceived_buy";
            this.cbReceived_buy.Size = new System.Drawing.Size(247, 28);
            this.cbReceived_buy.TabIndex = 23;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(208, 100);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(247, 26);
            this.dateTimePicker2.TabIndex = 22;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(208, 183);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(95, 35);
            this.button1.TabIndex = 26;
            this.button1.Text = "Update";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // frmTransactionDetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1323, 743);
            this.Controls.Add(this.gbBuy);
            this.Controls.Add(this.lblTransactionID);
            this.Controls.Add(this.gbTransactionDetail);
            this.Controls.Add(this.txtTransactionID);
            this.Controls.Add(this.gbRent);
            this.ForeColor = System.Drawing.Color.MidnightBlue;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmTransactionDetail";
            this.Text = "Transaction Details";
            this.Load += new System.EventHandler(this.frmTransactionDetail_Load);
            ((System.ComponentModel.ISupportInitialize)(this.iNVENTORYBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet2)).EndInit();
            this.gbRent.ResumeLayout(false);
            this.gbRent.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTransaction)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tRANSACTIONSBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbMovieForRentDataSetBindingSource1)).EndInit();
            this.gbTransactionDetail.ResumeLayout(false);
            this.gbBuy.ResumeLayout(false);
            this.gbBuy.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DateTimePicker dtpDueDate;
        private System.Windows.Forms.Label lblReceived;
        private System.Windows.Forms.DateTimePicker dtpReceivedDate;
        private System.Windows.Forms.Label lblReturned;
        private System.Windows.Forms.Label lblDueDate;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button btnTransUpdate;
        private System.Windows.Forms.ComboBox cbIsReturned;
        private System.Windows.Forms.ComboBox cbIsReceived;
        private System.Windows.Forms.TextBox txtTransactionID;
        private System.Windows.Forms.Label lblReceivedDate;
        private System.Windows.Forms.GroupBox gbRent;
        private System.Windows.Forms.DataGridView dgvTransaction;
        private dbMovieForRentDataSet dbMovieForRentDataSet;
        private System.Windows.Forms.BindingSource dbMovieForRentDataSetBindingSource;
        private System.Windows.Forms.BindingSource dbMovieForRentDataSetBindingSource1;
        private System.Windows.Forms.Label lblTransactionID;
        private dbMovieForRentDataSet1 dbMovieForRentDataSet1;
        private System.Windows.Forms.BindingSource tRANSACTIONSBindingSource;
        private dbMovieForRentDataSet1TableAdapters.TRANSACTIONSTableAdapter tRANSACTIONSTableAdapter;
        private dbMovieForRentDataSet2 dbMovieForRentDataSet2;
        private System.Windows.Forms.BindingSource iNVENTORYBindingSource;
        private dbMovieForRentDataSet2TableAdapters.INVENTORYTableAdapter iNVENTORYTableAdapter;
        private System.Windows.Forms.GroupBox gbTransactionDetail;
        private System.Windows.Forms.GroupBox gbBuy;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbReceived_buy;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRANSACTIONID;
        private System.Windows.Forms.DataGridViewTextBoxColumn CUSTOMERID;
        private System.Windows.Forms.DataGridViewTextBoxColumn MOVIEID;
        private System.Windows.Forms.DataGridViewTextBoxColumn RECEIVEDDATE;
        private System.Windows.Forms.DataGridViewTextBoxColumn DUEDATE;
        private System.Windows.Forms.DataGridViewTextBoxColumn STATUS;
    }
}