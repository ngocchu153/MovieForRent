﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MovieForRent
{
    public partial class frmIssueReciept : Form
    {
        public frmIssueReciept()
        {
            InitializeComponent();
        }

        private void loadDgvs()
        {
            SqlConnection connection = new SqlConnection();
            frmSearchForCustomer.connect(connection);

            string selectCmd = "Select MOVIE.MOVIEID, MOVIE.NAME, INVENTORY.QUANTITY  from INVENTORY join MOVIE on INVENTORY.MOVIEID = MOVIE.MOVIEID";
            SqlDataAdapter da = new SqlDataAdapter(selectCmd, connection);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgvInventory.DataSource = dt;

            selectCmd = "Select * from STOCKMOVEMENT";
            da = new SqlDataAdapter(selectCmd, connection);
            dt = new DataTable();
            da.Fill(dt);
            dgvStockManagement.DataSource = dt;

        }

        private void frmIssueReciept_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dbMovieForRentDataSet2.INVENTORY' table. You can move, or remove it, as needed.

            loadDgvs();
            
        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row;
                row = this.dgvInventory.Rows[e.RowIndex];

                txtMovieID.Text = row.Cells["MOVIEID"].Value.ToString();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtMovieID.Text != "")
            {
                if (txtIssueQuantity.Text=="0"&&txtReceiptQuantity.Text=="0")
                {
                    MessageBox.Show("Please Enter Receipt/Issue quantity! ");
                    return;
                }
                if (txtReceiptPrice.Text == "0" && txtReceiptQuantity.Text != "0")
                {
                    MessageBox.Show("Please Enter Receipt Price! ");
                    return;
                }
               //insertCmd.ExecuteNonQuery();
                SqlConnection connection = new SqlConnection();
                frmSearchForCustomer.connect(connection);
                //update quantity
                string updateQuantity = "UPDATE INVENTORY set QUANTITY = (QUANTITY+@RECEIPT-@ISSUE) WHERE (QUANTITY+@RECEIPT-@ISSUE)>=0 and MOVIEID = '" + txtMovieID.Text + "'";
                SqlCommand updateCmd = new SqlCommand(updateQuantity, connection);
                updateCmd.Parameters.AddWithValue("@RECEIPT", int.Parse(txtReceiptQuantity.Text));
                updateCmd.Parameters.AddWithValue("@ISSUE", int.Parse(txtIssueQuantity.Text));

                int verify = updateCmd.ExecuteNonQuery();

                if (verify == 1)
                {
                    //Insert new to StockMovement
                    string addCommand = "insert into STOCKMOVEMENT(MOVIEID,RECEIPTQUANTITY,ISSUEQUANTITY,RECEIPTPRICE,DATE,NOTE)values(@MOVIEID,@RECEIPTQUANTITY,@ISSUEQUANTITY,@RECEIPTPRICE,@DATE,@NOTE)";
                    SqlCommand insertCmd = new SqlCommand(addCommand, connection);

                    insertCmd.Parameters.AddWithValue("@MOVIEID", txtMovieID.Text);
                    insertCmd.Parameters.AddWithValue("@RECEIPTQUANTITY", int.Parse(txtReceiptQuantity.Text));
                    insertCmd.Parameters.AddWithValue("@ISSUEQUANTITY", int.Parse(txtIssueQuantity.Text));
                    insertCmd.Parameters.AddWithValue("@RECEIPTPRICE", int.Parse(txtReceiptPrice.Text));
                    insertCmd.Parameters.AddWithValue("@DATE", dtpDate.Value);
                    insertCmd.Parameters.AddWithValue("@NOTE", txtNote.Text);
                    
                    if (insertCmd.ExecuteNonQuery() == 1)
                    {
                        MessageBox.Show("Updated");
                    }
                    else
                    {
                        MessageBox.Show("Cant not add to STOCKMOVEMENT! ");
                        return;
                    }
                    loadDgvs();
                }
                else
                    MessageBox.Show("Movie quantity is not available! ");
                
                connection.Close();
            }
            else
                MessageBox.Show("Please choose a movie! ");
        }

        private void QuantityAndPrice_keyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back) ))
                e.Handled = true;
        }

        private void txtReceiptPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back) || (e.KeyChar == '.')))
                e.Handled = true;
        }
    }
}
