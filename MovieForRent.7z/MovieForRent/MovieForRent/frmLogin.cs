﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MovieForRent
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string cnnString = "Data Source=DESKTOP-M59GT3U\\SQLEXPRESS; Initial Catalog = dbMovieForRent; Integrated Security=true;";
            using (SqlConnection conn = new SqlConnection(cnnString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT USERTYPE FROM ACCOUNT WHERE Username = @username and Password = @password", conn))
                {
                   
                    cmd.Parameters.AddWithValue("@username", txtUsername.Text);
                    cmd.Parameters.AddWithValue("@password", txtPassword.Text);

                    var res = cmd.ExecuteScalar();
                   
                    if (res != null)
                    {
                        string usertype = res.ToString();
                        MessageBox.Show("You are login as " + res + " !");
                        this.Hide();
                        if (usertype == "Manager")
                        {
                            frmManage manage = new frmManage();
                            manage.Show();
                        }
                        else if (usertype == "Customer")
                        {
                            frmSearchForCustomer customer = new frmSearchForCustomer();
                            customer.Show();
                        }
                        else if (usertype == "Staff")
                        {
                            frmIssueReciept staff = new frmIssueReciept();
                            staff.Show();
                        }


                    }
                    else
                        MessageBox.Show("Login failed!");
                   
                }
            }
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {

        }

        private void linklbSignUp_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmSignUp newSignUp = new frmSignUp();
            newSignUp.Show();
        }
    }
}
